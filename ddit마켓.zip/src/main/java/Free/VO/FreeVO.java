package Free.VO;

public class FreeVO {
	
	private String blackdate;
	private int freeboard_id;
	private String mem_id;
	private String fb_detail;
	private String fb_createdate;
	private int fb_views;
	private String fb_reportcont;
	private int fb_reportstatus;
	private String fb_title;
	
	public String getBlackdate() {
		return blackdate;
	}
	public void setBlackdate(String blackdate) {
		this.blackdate = blackdate;
	}
	public int getFreeboard_id() {
		return freeboard_id;
	}
	public void setFreeboard_id(int freeboard_id) {
		this.freeboard_id = freeboard_id;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getFb_detail() {
		return fb_detail;
	}
	public void setFb_detail(String fb_detail) {
		this.fb_detail = fb_detail;
	}
	public String getFb_createdate() {
		return fb_createdate;
	}
	public void setFb_createdate(String fb_createdate) {
		this.fb_createdate = fb_createdate;
	}
	public int getFb_views() {
		return fb_views;
	}
	public void setFb_views(int fb_views) {
		this.fb_views = fb_views;
	}
	public String getFb_reportcont() {
		return fb_reportcont;
	}
	public void setFb_reportcont(String fb_reportcont) {
		this.fb_reportcont = fb_reportcont;
	}
	public int getFb_reportstatus() {
		return fb_reportstatus;
	}
	public void setFb_reportstatus(int fb_reportstatus) {
		this.fb_reportstatus = fb_reportstatus;
	}
	public String getFb_title() {
		return fb_title;
	}
	public void setFb_title(String fb_title) {
		this.fb_title = fb_title;
	}
	
}
