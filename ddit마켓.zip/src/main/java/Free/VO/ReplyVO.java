package Free.VO;

public class ReplyVO {

	private int reply_id;
	private String reply_content;
	private String reply_regdate;
	private int freeboard_id;
	private String mem_id;
	
	public int getReply_id() {
		return reply_id;
	}
	public void setReply_id(int reply_id) {
		this.reply_id = reply_id;
	}
	public String getReply_content() {
		return reply_content;
	}
	public void setReply_content(String reply_content) {
		this.reply_content = reply_content;
	}
	public String getReply_regdate() {
		return reply_regdate;
	}
	public void setReply_regdate(String reply_regdate) {
		this.reply_regdate = reply_regdate;
	}
	public int getFreeboard_id() {
		return freeboard_id;
	}
	public void setFreeboard_id(int freeboard_id) {
		this.freeboard_id = freeboard_id;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
}
