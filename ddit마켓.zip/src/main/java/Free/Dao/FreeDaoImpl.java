package Free.Dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import Free.VO.FreeVO;
import Free.VO.ReplyVO;
import Util.mybatisSqlSessionFactory;

public class FreeDaoImpl implements IFreeDao {

	private static FreeDaoImpl dao;	
	
	private FreeDaoImpl() {
	}
	
	public static FreeDaoImpl getInstance() {
		if(dao == null) dao = new FreeDaoImpl();
		return dao;
	}

	@Override
	public int insertFree(FreeVO vo) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.insert("free.insertFree", vo);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		}
		return cnt;
	}

	@Override
	public int updateFree(FreeVO vo) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.update("free.updateFree", vo);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		}
		return cnt;
	}

	@Override
	public int deleteFree(FreeVO vo) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.delete("free.deleteFree", vo);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		}
		return cnt;
	}

	@Override
	public List<FreeVO> selectFreeList(Map<String, Object> map) {
		SqlSession session = null;
		List<FreeVO> list = null;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			list = session.selectList("free.selectFreeList", map);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		} return list;
	}

	@Override
	public int incrementFreeViews(int id) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.update("free.incrementFreeViews", id);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		}
		return cnt;
	}

	@Override
	public int totalFreeCount(Map<String, Object> map) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.selectOne("free.totalFreeCount", map);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		} return cnt;
	}

	@Override
	public int insertReply(ReplyVO vo) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.delete("free.insertReply", vo);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		}
		return cnt;
	}

	@Override
	public int updateReply(ReplyVO vo) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.delete("free.updateReply", vo);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		}
		return cnt;
	}

	@Override
	public int deleteReply(ReplyVO rid) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.delete("free.deleteReply", rid);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		}
		return cnt;
	}

	@Override
	public List<ReplyVO> selectReply(int freeid) {
		SqlSession session = null;
		List<ReplyVO> list = null;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			list = session.selectList("free.selectReply", freeid);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		} return list;
	}

	@Override
	public FreeVO getFree(int freeid) {
		SqlSession session = null;
		FreeVO vo = null;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			vo = session.selectOne("free.getFree", freeid);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		} return vo;
	}

	@Override
	public int deleteFreeAdmin(FreeVO vo) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.delete("free.deleteFreeAdmin", vo);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		}
		return cnt;
	}
}
