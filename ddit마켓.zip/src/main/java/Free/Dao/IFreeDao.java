package Free.Dao;

import java.util.List;
import java.util.Map;

import Free.VO.FreeVO;
import Free.VO.ReplyVO;

public interface IFreeDao {
	
	public FreeVO getFree(int freeid);
	
	public int insertFree(FreeVO vo);
	
	public int updateFree(FreeVO vo);
	
	public int deleteFree(FreeVO vo);
	
	public List<FreeVO> selectFreeList(Map<String, Object> map);
	
	public int incrementFreeViews(int id);
	
	public int totalFreeCount(Map<String, Object> map);
	
	public int insertReply(ReplyVO vo);
	
	public int updateReply(ReplyVO vo);

	public int deleteReply(ReplyVO rid);

	public List<ReplyVO> selectReply(int freeid);
	
	public int deleteFreeAdmin(FreeVO vo);
	
}
