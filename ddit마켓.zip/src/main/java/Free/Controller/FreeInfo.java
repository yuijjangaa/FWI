package Free.Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Free.Service.FreeServiceImpl;
import Free.Service.IFreeService;
import Free.VO.FreeVO;


@WebServlet("/FreeInfo.do")
public class FreeInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;

		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			request.setCharacterEncoding("utf-8");
			response.setCharacterEncoding("utf-8");
			
			int freeid = Integer.parseInt(request.getParameter("freeid"));
			String update = request.getParameter("update");
			IFreeService service = FreeServiceImpl.getInstance();
			
			FreeVO vo = new FreeVO();
			
			vo = service.getFree(freeid);
			service.incrementFreeViews(freeid);
			
			request.setAttribute("free", vo);
			
			if(update == null) {
				request.getRequestDispatcher("/free/freeDetail.jsp").forward(request, response);
			} else {
				request.getRequestDispatcher("/free/modifyFree.jsp").forward(request, response);
			}
			
	}

}
