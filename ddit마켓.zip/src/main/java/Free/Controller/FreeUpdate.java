package Free.Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Free.Service.FreeServiceImpl;
import Free.Service.IFreeService;
import Free.VO.FreeVO;


@WebServlet("/FreeUpdate.do")
public class FreeUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		String memid = (String)session.getAttribute("userId");
		FreeVO vo = new FreeVO();
		
		vo.setFreeboard_id(Integer.parseInt(request.getParameter("id")));
		vo.setMem_id(memid);
		vo.setFb_title(request.getParameter("title"));
		vo.setFb_detail(request.getParameter("detail"));
		
		IFreeService service = FreeServiceImpl.getInstance();
		
		int res = service.updateFree(vo);
		request.setAttribute("result", res);
		
		request.getRequestDispatcher("/annoview/result.jsp").forward(request, response);
		
	}

}
