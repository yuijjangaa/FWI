package Free.Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Free.Service.FreeServiceImpl;
import Free.Service.IFreeService;
import Free.VO.FreeVO;


@WebServlet("/FreeWrite.do")
public class FreeWrite extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		HttpSession session = request.getSession();
		String memid = (String)session.getAttribute("userId");
		//요청시 전송데이터 받기 
		FreeVO vo = new FreeVO();
		
		vo.setFb_detail(request.getParameter("detail"));
		vo.setFb_title(request.getParameter("title"));
		vo.setMem_id(memid);
		
		//service객체 얻기
		IFreeService service = FreeServiceImpl.getInstance();
		
		//service메소드호출하기 - 결과값 받기
		int res = service.insertFree(vo);
		
		//결과값을 request에 저장
		request.setAttribute("result", res);
		
		//view페이지로 이동
		request.getRequestDispatcher("/annoview/result.jsp").forward(request, response);
	}

}
