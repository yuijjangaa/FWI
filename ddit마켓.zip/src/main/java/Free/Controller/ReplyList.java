package Free.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Free.Service.FreeServiceImpl;
import Free.Service.IFreeService;
import Free.VO.ReplyVO;


@WebServlet("/ReplyList.do")
public class ReplyList extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 아이디로
		int freeid = Integer.parseInt(request.getParameter("freeid"));
		// 서비스를 불러와서
		IFreeService service = FreeServiceImpl.getInstance();
		// 그에대한 리스트를 단다.
		List<ReplyVO> list = service.selectReply(freeid);
		// 리스트를 jsp로 호출해준다.
		request.setAttribute("replylist", list);
		
		request.getRequestDispatcher("/freeview/replylist.jsp").forward(request, response);
	
	}

}
