package Free.Controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Free.Service.FreeServiceImpl;
import Free.Service.IFreeService;
import Free.VO.FreeVO;
import Free.VO.PageFreeVO;


@WebServlet("/FreeList.do")
public class FreeList extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	request.setCharacterEncoding("utf-8");
	response.setCharacterEncoding("utf-8");
	
	int page = Integer.parseInt(request.getParameter("page")); // 최초 실행시 1
	String stype = request.getParameter("stype"); // 최초 실행 시 없다
	String sword = request.getParameter("sword"); //
	
	IFreeService service = FreeServiceImpl.getInstance();
	
	PageFreeVO fvo = service.pageFreeInfo(page, stype, sword);
		
	
	Map<String, Object> map = new HashMap<>();
	map.put("start", fvo.getStart());
	map.put("end", fvo.getEnd());
	map.put("stype", stype);
	map.put("sword", sword);
	List<FreeVO> list = service.selectFreeList(map); 
		
	//결과값을 request에 저장
	request.setAttribute("listvalue", list);
	request.setAttribute("startPage", fvo.getStartPage());
	request.setAttribute("endPage", fvo.getEndPage());
	request.setAttribute("totalPage", fvo.getTotalPage());
	
	//view페이지로 이동
	request.getRequestDispatcher("/freeview/freelist.jsp").forward(request, response);
	}
}