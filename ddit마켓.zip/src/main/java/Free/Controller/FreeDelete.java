package Free.Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Free.Service.FreeServiceImpl;
import Free.Service.IFreeService;
import Free.VO.FreeVO;


@WebServlet("/FreeDelete.do")
public class FreeDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int freeid = Integer.parseInt(request.getParameter("freeid")); 
		HttpSession session = request.getSession();
		String memid = (String)session.getAttribute("userId");
		FreeVO vo = new FreeVO();
		IFreeService service = FreeServiceImpl.getInstance();
		
		vo.setFreeboard_id(freeid);
		vo.setMem_id(memid);
		int res = 0;
		if(memid == null) {
			res = service.deleteFreeAdmin(vo);
			
		} else {
			res = service.deleteFree(vo);
		}
		
		
		request.setAttribute("result", res);	
		
		request.getRequestDispatcher("/annoview/result.jsp").forward(request, response);
	}

}
