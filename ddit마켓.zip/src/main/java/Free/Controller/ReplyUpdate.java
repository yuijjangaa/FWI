package Free.Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Free.Service.FreeServiceImpl;
import Free.Service.IFreeService;
import Free.VO.ReplyVO;


@WebServlet("/ReplyUpdate.do")
public class ReplyUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		int replyid = Integer.parseInt(request.getParameter("reply"));
		HttpSession session = request.getSession();
		String memid = (String)session.getAttribute("userId");
		String cont = request.getParameter("cont");
		
		ReplyVO vo = new ReplyVO();
		
		vo.setReply_id(replyid);
		vo.setMem_id(memid);
		vo.setReply_content(cont);
		
		IFreeService service = FreeServiceImpl.getInstance();
		
		int res = service.updateReply(vo);
		
		request.setAttribute("result", res);
		
		request.getRequestDispatcher("/annoview/result.jsp").forward(request, response);
	}

}
