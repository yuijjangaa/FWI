package Free.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Anno.VO.PageVO;
import Free.Dao.FreeDaoImpl;
import Free.Dao.IFreeDao;
import Free.VO.FreeVO;
import Free.VO.PageFreeVO;
import Free.VO.ReplyVO;

public class FreeServiceImpl implements IFreeService{
	private static FreeServiceImpl service;
	private static IFreeDao dao;
	
	private FreeServiceImpl() {
		dao = FreeDaoImpl.getInstance();
	}
	public static FreeServiceImpl getInstance() {
		if(service == null) service = new FreeServiceImpl();
		return service;
	}
	
	
	@Override
	public int insertFree(FreeVO vo) {
		return dao.insertFree(vo);
	}

	@Override
	public int updateFree(FreeVO vo) {
		return dao.updateFree(vo);
	}

	@Override
	public int deleteFree(FreeVO vo) {
		return dao.deleteFree(vo);
	}

	@Override
	public List<FreeVO> selectFreeList(Map<String, Object> map) {
		return dao.selectFreeList(map);
	}

	@Override
	public int incrementFreeViews(int id) {
		return dao.incrementFreeViews(id);
	}

	@Override
	public int totalFreeCount(Map<String, Object> map) {
		return dao.totalFreeCount(map);
	}

	@Override
	public int insertReply(ReplyVO vo) {
		return dao.insertReply(vo);
	}

	@Override
	public int updateReply(ReplyVO vo) {
		return dao.updateReply(vo);
	}

	@Override
	public int deleteReply(ReplyVO rid) {
		return dao.deleteReply(rid);
	}

	@Override
	public List<ReplyVO> selectReply(int freeid) {
		return dao.selectReply(freeid);
	}
	@Override
	public PageFreeVO pageFreeInfo(int page, String stype, String sword) {
		//전체글 갯수 구하기
				Map<String, Object> map = new HashMap<>();
				
				map.put("sword", sword);
				map.put("stype", stype);
				
				int count = this.totalFreeCount(map);
				
				//전체페이지수 구하기
				int totalPage = (int)Math.ceil((double)count / PageFreeVO.getPerList());
				
				//start, end 구하기
				int start = (page-1) * PageFreeVO.getPerList() + 1;
				int end = start + PageFreeVO.getPerList() - 1;
				
				if(end > count) end = count;
				
				//시작페이지 끝페이지
				int perPage = PageFreeVO.getPerPage();
				int startPage = ((page-1) / perPage * perPage) + 1;
				
				int endPage = startPage + perPage - 1;
				if(endPage > totalPage) endPage = totalPage;
				
				PageFreeVO vo = new PageFreeVO();
				vo.setStart(start);
				vo.setEnd(end);
				
				vo.setStartPage(startPage);
				vo.setEndPage(endPage);
				vo.setTotalPage(totalPage);
				
				return vo;
	}
	@Override
	public FreeVO getFree(int freeid) {
		return dao.getFree(freeid);
	}
	@Override
	public int deleteFreeAdmin(FreeVO vo) {
		return dao.deleteFreeAdmin(vo);
	}
}
