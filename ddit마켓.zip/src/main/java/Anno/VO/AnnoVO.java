package Anno.VO;

public class AnnoVO {

	private String anno_id;
	private String anno_title;
	private String anno_detail;
	private String anno_createdate;
	private int anno_views;
	public String getAnno_id() {
		return anno_id;
	}
	public void setAnno_id(String anno_id) {
		this.anno_id = anno_id;
	}
	public String getAnno_title() {
		return anno_title;
	}
	public void setAnno_title(String anno_title) {
		this.anno_title = anno_title;
	}
	public String getAnno_detail() {
		return anno_detail;
	}
	public void setAnno_detail(String anno_detail) {
		this.anno_detail = anno_detail;
	}
	public String getAnno_createdate() {
		return anno_createdate;
	}
	public void setAnno_createdate(String anno_createdate) {
		this.anno_createdate = anno_createdate;
	}
	public int getAnno_views() {
		return anno_views;
	}
	public void setAnno_views(int anno_views) {
		this.anno_views = anno_views;
	}
	
	
}
