package Anno.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Anno.Dao.AnnoDaoImpl;
import Anno.Dao.IAnnoDao;
import Anno.VO.AnnoVO;
import Anno.VO.PageVO;

public class AnnoServiceImpl implements IAnnoService {
	private static AnnoServiceImpl service;
	private static IAnnoDao dao;
	
	private AnnoServiceImpl() {
		dao = AnnoDaoImpl.getInstance();
	}
	
	public static AnnoServiceImpl getInstance() {
		if(service == null) service = new AnnoServiceImpl();
		return service;
	}

	@Override
	public int insertAnno(AnnoVO vo) {
		return dao.insertAnno(vo);
	}

	@Override
	public int updateAnno(AnnoVO vo) {
		return dao.updateAnno(vo);
	}

	@Override
	public int deleteAnno(int id) {
		return dao.deleteAnno(id);
	}

	@Override
	public List<AnnoVO> selectAnnoList(Map<String, Object> map) {
		return dao.selectAnnoList(map);
	}

	@Override
	public int incrementViews(int id) {
		return dao.incrementViews(id);
	}

	@Override
	public int totalCount(Map<String, Object> map) {
		return dao.totalCount(map);
	}

	@Override
	public PageVO pageInfo(int page, String stype, String sword) {
		//전체글 갯수 구하기
				Map<String, Object> map = new HashMap<>();
				
				map.put("sword", sword);
				map.put("stype", stype);
				
				int count = this.totalCount(map);
				
				//전체페이지수 구하기
				int totalPage = (int)Math.ceil((double)count / PageVO.getPerList());
				
				//start, end 구하기
				int start = (page-1) * PageVO.getPerList() + 1;
				int end = start + PageVO.getPerList() - 1;
				
				if(end > count) end = count;
				
				//시작페이지 끝페이지
				int perPage = PageVO.getPerPage();
				int startPage = ((page-1) / perPage * perPage) + 1;
				
				int endPage = startPage + perPage - 1;
				if(endPage > totalPage) endPage = totalPage;
				
				PageVO vo = new PageVO();
				vo.setStart(start);
				vo.setEnd(end);
				
				vo.setStartPage(startPage);
				vo.setEndPage(endPage);
				vo.setTotalPage(totalPage);
				
				return vo;
	}
}
