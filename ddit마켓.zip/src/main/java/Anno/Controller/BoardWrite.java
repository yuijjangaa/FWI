package Anno.Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Anno.Service.AnnoServiceImpl;
import Anno.Service.IAnnoService;
import Anno.VO.AnnoVO;



@WebServlet("/BoardWrite.do")
public class BoardWrite extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		//요청시 전송데이터 받기 
		AnnoVO vo = new AnnoVO();
		
		vo.setAnno_detail(request.getParameter("detail"));
		vo.setAnno_title(request.getParameter("title"));
		
		//service객체 얻기
		IAnnoService service = AnnoServiceImpl.getInstance();
		
		//service메소드호출하기 - 결과값 받기
		int res = service.insertAnno(vo);
		
		//결과값을 request에 저장
		request.setAttribute("result", res);
		
		//view페이지로 이동
		request.getRequestDispatcher("/annoview/result.jsp").forward(request, response);
	}

}
