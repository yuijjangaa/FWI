package Anno.Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Free.Service.FreeServiceImpl;
import Free.Service.IFreeService;
import Free.VO.FreeVO;


@WebServlet("/BoardUpdate.do")
public class BoardUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		//요청 시 전송데이터 
		FreeVO vo = new FreeVO();
		
		vo.setFreeboard_id(Integer.parseInt(request.getParameter("id")));
		vo.setMem_id(request.getParameter("mem"));
		vo.setFb_detail(request.getParameter("detail"));				 
		vo.setFb_title(request.getParameter("title"));
		
		//service객체 얻기
		IFreeService service = FreeServiceImpl.getInstance();
				
		//service메소드 호출 - 결과값 얻기
		int res = service.updateFree(vo);
		
		//결과값을 request에 저장
		request.setAttribute("result", res);
		
		//view페이지로 이동
		request.getRequestDispatcher("/annoview/result.jsp").forward(request, response);
	}

}
