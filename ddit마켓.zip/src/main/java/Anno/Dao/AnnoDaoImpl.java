package Anno.Dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import Anno.VO.AnnoVO;
import Util.mybatisSqlSessionFactory;

public class AnnoDaoImpl implements IAnnoDao{
private static AnnoDaoImpl dao;
    
    private AnnoDaoImpl() {
    }
    
    public static AnnoDaoImpl getInstance() {
        if(dao == null) dao = new AnnoDaoImpl();
        return dao;
    }
	@Override
	public int insertAnno(AnnoVO vo) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.insert("anno.insertAnno", vo);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		}
		return cnt;
	}

	@Override
	public int updateAnno(AnnoVO vo) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.update("anno.updateAnno", vo);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		}
		return cnt;
	}

	@Override
	public int deleteAnno(int id) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.delete("anno.deleteAnno", id);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		}
		return cnt;
	}

	@Override
	public List<AnnoVO> selectAnnoList(Map<String, Object> map) {
		SqlSession session = null;
		List<AnnoVO> list = null;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			list = session.selectList("anno.selectAnnoList", map);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		} return list;
	}

	@Override
	public int incrementViews(int id) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.update("anno.incrementViews", id);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		}
		return cnt;
	}

	@Override
	public int totalCount(Map<String, Object> map) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.selectOne("anno.totalCount", map);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		} return cnt;
	
	}
}