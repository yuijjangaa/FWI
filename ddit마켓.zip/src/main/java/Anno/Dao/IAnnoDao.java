package Anno.Dao;

import java.util.List;
import java.util.Map;

import Anno.VO.AnnoVO;

public interface IAnnoDao {
	/**
	 * parameter로 입력 받은 게시글 정보를 입력하는 메소드
	 * @param vo 입력받은 vo
	 * @return 게시판 글 작성
	 */
	public int insertAnno(AnnoVO vo);
	/**
	 * parameter로 입력 받은 게시글 정보로 수정하는 메소드
	 * @param vo 입력받은 vo
	 * @return 게시글 업데이트
	 */
	public int updateAnno(AnnoVO vo);
	/**
	 * parameter로 입력 받은 게시글 id를 삭제하는 메소드
	 * @param id 입력받을 id
	 * @return 
	 */
	public int deleteAnno(int id);
	/**
	 * parameter로 입력 받은 값을 조회하는 메소드 
	 * @param map
	 * @return
	 */
	public List<AnnoVO> selectAnnoList(Map<String, Object> map);
	/**
	 * 입력 받을 때마다 조회수가 증가하는 메서드
	 * @param id
	 * @return
	 */
	public int incrementViews(int id);
	/**
	 * 전체글의 개수를 구하는 메서드
	 * @param map
	 * @return
	 */
	public int totalCount(Map<String, Object> map);
	
	
		
}
