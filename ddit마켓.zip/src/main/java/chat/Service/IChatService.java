package chat.Service;

import java.util.List;

import chat.VO.ChatVO;
import chat.VO.TradeVO;
import prodboard.VO.ProdVO;

public interface IChatService {
    /**
     * 거래중인 상품의 대화내용을 가져오는 메소드
     * 
     * @param vo 거래 정보가 담긴 vo객체
     * @return 채팅방 정보
     */
    public ChatVO getChat(ChatVO vo);
    
    /**
     * 전체 채팅방 정보를 불러오는 메소드
     * 
     * @param vo 채팅방 정보가 담긴 VO객체
     * @return 채팅방 정보 리스트
     */
    public List<ChatVO> getChatList(ChatVO vo);
    
    /** 
     * 채팅내역을 생성하는 메소드
     * 
     * @param vo 채팅 정보가 담긴 VO객체
     * @return 성공 1, 실패 0
     */
    public int createChat(ChatVO vo);
    
    /**
     * 거래가 종료된 상품의 상태를 변경하는 메소드
     * 
     * @param id 거래중인 채팅방 ID
     * @return 성공 1, 실패 0
     */
    public int updateChatStatus(ChatVO vo);
    
    /** 
     * 물품게시글에 대한 판매자 정보를 뽑아오는 메소드
     * 
     * @param vo 판매자의 정보가 담긴 객체
     * @return 판매자 vo객체
     */
    public ProdVO getSeller(ProdVO vo);

    public String getBuyerId(String chat_id);
    
    public String getChatId(ChatVO chatVO);
    
    public ChatVO getChatEnd(ChatVO vo);
    
    public ChatVO getChatById(String chatId);
    
    public int insertTrade(TradeVO vo);
    
    public TradeVO getTrade(String prodId);
    
    public List<TradeVO> getTradeList(String memId);
}
