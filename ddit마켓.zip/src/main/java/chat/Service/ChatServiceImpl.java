package chat.Service;

import java.util.List;

import chat.Dao.ChatDaoImpl;
import chat.Dao.IChatDao;
import chat.VO.ChatVO;
import chat.VO.TradeVO;
import prodboard.VO.ProdVO;

public class ChatServiceImpl implements IChatService {
    private static ChatServiceImpl service;
    private static IChatDao dao;
    
    private ChatServiceImpl() {
        dao = ChatDaoImpl.getInstance();
    }
    
    public static ChatServiceImpl getInstance() {
        if(service == null) service = new ChatServiceImpl();
        return service;
    }

    @Override
    public ChatVO getChat(ChatVO vo) {
        return dao.getChat(vo);
    }

    @Override
    public List<ChatVO> getChatList(ChatVO vo) {
        return dao.getChatList(vo);
    }

    @Override
    public int createChat(ChatVO vo) {
        return dao.createChat(vo);
    }

    @Override
    public int updateChatStatus(ChatVO vo) {
        return dao.updateChatStatus(vo);
    }

    @Override
    public ProdVO getSeller(ProdVO vo) {
        return dao.getSeller(vo);
    }

    @Override
    public String getBuyerId(String chat_id) {
        return dao.getBuyerId(chat_id);
    }

    @Override
    public String getChatId(ChatVO chatVO) {
        return dao.getChatId(chatVO);
    }

    @Override
    public ChatVO getChatEnd(ChatVO vo) {
        return dao.getChatEnd(vo);
    }

    @Override
    public ChatVO getChatById(String chatId) {
        return dao.getChatById(chatId);
    }

    @Override
    public int insertTrade(TradeVO vo) {
        return dao.insertTrade(vo);
    }

    @Override
    public TradeVO getTrade(String prodId) {
        return dao.getTrade(prodId);
    }

    @Override
    public List<TradeVO> getTradeList(String memId) {
        return dao.getTradeList(memId);
    }

}
