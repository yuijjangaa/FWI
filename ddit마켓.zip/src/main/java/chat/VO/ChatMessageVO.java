package chat.VO;

public class ChatMessageVO {
    private String buyerId;
    private String prodId;
    // state
    private int state;
    // 내용
    private String value;
    // getter, setter
    
    public int getState() {
      return state;
    }
    public String getBuyerId() {
        return buyerId;
    }
    public void setBuyerId(String buyerId) {
        this.buyerId = buyerId;
    }
    public String getProdId() {
        return prodId;
    }
    public void setProdId(String prodId) {
        this.prodId = prodId;
    }
    public void setState(int state) {
      this.state = state;
    }
    public String getValue() {
      return value;
    }
    public void setValue(String value) {
      this.value = value;
    }

}
