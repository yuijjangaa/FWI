package chat.VO;

public class AlarmListVO {
    private int alarm_id;
    private int alarm_cnt;
    private String chat_id;
    private String seller_id;
    private String prod_id;
    private String prod_name;
    
    public String getProd_name() {
        return prod_name;
    }
    public void setProd_name(String prod_name) {
        this.prod_name = prod_name;
    }
    public int getAlarm_id() {
        return alarm_id;
    }
    public void setAlarm_id(int alarm_id) {
        this.alarm_id = alarm_id;
    }
    public int getAlarm_cnt() {
        return alarm_cnt;
    }
    public void setAlarm_cnt(int alarm_cnt) {
        this.alarm_cnt = alarm_cnt;
    }
    public String getChat_id() {
        return chat_id;
    }
    public void setChat_id(String chat_id) {
        this.chat_id = chat_id;
    }
    public String getSeller_id() {
        return seller_id;
    }
    public void setSeller_id(String seller_id) {
        this.seller_id = seller_id;
    }
    public String getProd_id() {
        return prod_id;
    }
    public void setProd_id(String prod_id) {
        this.prod_id = prod_id;
    }

}
