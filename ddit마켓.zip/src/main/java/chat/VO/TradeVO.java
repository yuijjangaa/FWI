package chat.VO;

public class TradeVO {
    private int trade_id;
    private String prod_id;
    private String prod_name;
    private String chat_id;
    private String seller_id;
    private String buy_date;
    
    public int getTrade_id() {
        return trade_id;
    }
    public void setTrade_id(int trade_id) {
        this.trade_id = trade_id;
    }
    public String getProd_id() {
        return prod_id;
    }
    public void setProd_id(String prod_id) {
        this.prod_id = prod_id;
    }
    public String getChat_id() {
        return chat_id;
    }
    public void setChat_id(String chat_id) {
        this.chat_id = chat_id;
    }
    public String getSeller_id() {
        return seller_id;
    }
    public void setSeller_id(String seller_id) {
        this.seller_id = seller_id;
    }
    public String getBuy_date() {
        return buy_date;
    }
    public void setBuy_date(String buy_date) {
        this.buy_date = buy_date;
    }
    public String getProd_name() {
        return prod_name;
    }
    public void setProd_name(String prod_name) {
        this.prod_name = prod_name;
    }
    
}
