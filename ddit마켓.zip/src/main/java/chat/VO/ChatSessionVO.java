package chat.VO;

import javax.websocket.Session;

public class ChatSessionVO {
 // WebSocket 세션
    private Session session;
    // id
    private String id;
    // getter, setter
    public Session getSession() {
      return session;
    }
    public void setSession(Session session) {
      this.session = session;
    }
    public String getId() {
      return id;
    }
    public void setId(String id) {
      this.id = id;
    }

}
