package chat.VO;

public class ChatVO {
    private String chat_id;
    private String prod_id;
    private String seller_id;
    private String mem_id;
    private String chat_status;
    
    
    public String getSeller_id() {
        return seller_id;
    }
    public void setSeller_id(String seller_id) {
        this.seller_id = seller_id;
    }
    public String getChat_id() {
        return chat_id;
    }
    public void setChat_id(String chat_id) {
        this.chat_id = chat_id;
    }
    public String getProd_id() {
        return prod_id;
    }
    public void setProd_id(String prod_id) {
        this.prod_id = prod_id;
    }
    public String getMem_id() {
        return mem_id;
    }
    public void setMem_id(String mem_id) {
        this.mem_id = mem_id;
    }
    public String getChat_status() {
        return chat_status;
    }
    public void setChat_status(String chat_status) {
        this.chat_status = chat_status;
    }
    
}
