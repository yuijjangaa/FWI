package chat.Dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import Util.mybatisSqlSessionFactory;
import chat.VO.ChatVO;
import chat.VO.TradeVO;
import prodboard.VO.ProdVO;

public class ChatDaoImpl implements IChatDao {
    private static ChatDaoImpl dao;
    
    private ChatDaoImpl() {
    }
    
    public static ChatDaoImpl getInstance() {
        if(dao == null) dao = new ChatDaoImpl();
        return dao;
    }

    @Override
    public ChatVO getChat(ChatVO vo) {
        SqlSession session = null;
        ChatVO cvo = null;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            cvo = session.selectOne("chat.getChat", vo);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return cvo;
    }

    @Override
    public List<ChatVO> getChatList(ChatVO vo) {
        SqlSession session = null;
        List<ChatVO> list = null;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            list = session.selectList("chat.getChatList", vo);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return list;
    }

    @Override
    public int createChat(ChatVO vo) {
        SqlSession session = null;
        int cnt = 0;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            cnt = session.insert("chat.createChat", vo);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.commit();
            session.close();
        }
        return cnt;
    }

    @Override
    public int updateChatStatus(ChatVO vo) {
        SqlSession session = null;
        int cnt = 0;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            cnt = session.update("chat.updateChatStatus", vo);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.commit();
            session.close();
        }
        return cnt;
    }

    @Override
    public ProdVO getSeller(ProdVO vo) {
        SqlSession session = null;
        ProdVO pvo = null;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            pvo = session.selectOne("chat.getSeller", vo);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return pvo;
    }

    @Override
    public String getBuyerId(String id) {
        SqlSession session = null;
        String buyerId = "";
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            buyerId = session.selectOne("chat.getBuyerId", id);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return buyerId;
    }

    @Override
    public String getChatId(ChatVO chatVO) {
        SqlSession session = null;
        String chatId = null;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            chatId = session.selectOne("chat.getChatId", chatVO);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return chatId;
    }

    @Override
    public ChatVO getChatEnd(ChatVO vo) {
        SqlSession session = null;
        ChatVO cvo = null;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            cvo = session.selectOne("chat.getChatEnd", vo);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return cvo;
    }

    @Override
    public ChatVO getChatById(String chatId) {
        SqlSession session = null;
        ChatVO vo = null;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            vo = session.selectOne("chat.getChatById", chatId);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return vo;
    }

    @Override
    public int insertTrade(TradeVO vo) {
        SqlSession session = null;
        int cnt = 0;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            cnt = session.insert("chat.insertTrade", vo);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.commit();
            session.close();
        }
        return cnt;
    }

    @Override
    public TradeVO getTrade(String prodId) {
        SqlSession session = null;
        TradeVO vo = null;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            vo = session.selectOne("chat.getTrade", prodId);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return vo;
    }

    @Override
    public List<TradeVO> getTradeList(String memId) {
        SqlSession session = null;
        List<TradeVO> list = null;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            list = session.selectList("chat.getTradeList", memId);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return list;
    }
}
