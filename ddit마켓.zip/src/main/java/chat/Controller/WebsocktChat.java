package chat.Controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import com.google.gson.Gson;

import alarm.Service.AlarmServiceImpl;
import alarm.Service.IAlarmService;
import alarm.VO.AlarmVO;
import chat.Service.ChatServiceImpl;
import chat.Service.IChatService;
import chat.VO.ChatMessageVO;
import chat.VO.ChatSessionVO;
import chat.VO.ChatVO;
import prodboard.VO.ProdVO;

@ServerEndpoint("/chatting")
public class WebsocktChat {
 // 유저 리스트
    private static List<ChatSessionVO> users = new LinkedList<>();
    // JSON을 파싱하는 클래스
    private Gson gson = new Gson();
    // WebSocket session으로 ChatSession을 탐색하는 함수
    private ChatSessionVO getSession(Session userSession) {
      // session 클래스와 ChatSession 클래스의 session 변수를 비교해서 탐색해 온다.
      Optional<ChatSessionVO> data = users.stream().filter(x -> x.getSession() == userSession).findFirst();
      // 데이터가 있으면
      if (data.isPresent()) {
        // 리턴
        return data.get();
      }
      // 없으면 null
      return null;
    }
    // 세션 만들기
    private ChatSessionVO createSession(ChatMessageVO msg, Session userSession) {
      // 먼저 기존 세션에 있는지 확인
      ChatSessionVO session = getSession(userSession);
      // 세션이 없으면
      if (session == null) {
        // 인스턴스 생성
        session = new ChatSessionVO();
        // 세션 저장
        session.setSession(userSession);
        // user 리스트에 추가
        users.add(session);
      }
      // id 저장
      session.setId(msg.getBuyerId());
      // session 리턴
      return session;
    }
    
    
    // WebSocket이 접속될 때 호출되는 함수
    @OnOpen
    public void handleOpen(Session userSession) {
    }
    
    
    // 브라우저로부터 메시지가 오면 호출되는 함수
    @OnMessage
    public void handleMessage(String message, Session userSession) {
      // 메시지가 JSON 타임으로 오는데 ChatMessage 클래스로 변환
      ChatMessageVO msg = gson.fromJson(message, ChatMessageVO.class);
      // State가 0이라면 초기 접속
      
      String id = msg.getBuyerId();
      String prodId = msg.getProdId();
      
      ChatVO vo = new ChatVO();
      vo.setMem_id(id);
      vo.setProd_id(prodId);
      
      
      ProdVO prodVo = new ProdVO();
      prodVo.setMem_id(id);
      prodVo.setProd_id(prodId);
      
      IAlarmService alarmservice = AlarmServiceImpl.getInstance();
      IChatService chatService = ChatServiceImpl.getInstance();
      
      // 판매자
      String sellerId = "";
      ProdVO prodRes = chatService.getSeller(prodVo);
      if (prodRes != null) {
          sellerId = prodRes.getMem_id();
          vo.setSeller_id(sellerId);
          
          ChatVO chatVo = new ChatVO();
          chatVo.setSeller_id(sellerId);
          chatVo.setProd_id(prodRes.getProd_id());
          
          String chatId = chatService.getChatId(chatVo);
          String buyerId = chatService.getBuyerId(chatId);
          vo.setMem_id(buyerId);
      } // 끝
      
      ChatVO cvo = chatService.getChat(vo);
      if (cvo == null) {
           int createChatRes = chatService.createChat(vo);
          if(createChatRes>0) {
              cvo = chatService.getChat(vo);
          }
      }
      // 알람있는지 확인
      AlarmVO avo = alarmservice.checkAlarm(cvo.getChat_id());
      
      String chatId = "D:\\CHAT\\" + cvo.getChat_id() + ".txt";
      
      if (msg.getState() == 0) {
        // 세션 만들기
        createSession(msg, userSession);
        if(avo == null) {
            alarmservice.newAlarm(cvo.getChat_id());
        }
        try {
          // 파일로부터 채팅 내용을 읽어와서 보내기
          userSession.getBasicRemote().sendText(readFile(chatId));
        } catch (Throwable e) {
          // 에러가 발생할 경우.
          e.printStackTrace();
        }
      // State가 1이라면 일반 메시지
      } else if (msg.getState() == 1) {
        // 세션 확인 하기
        if (getSession(userSession) != null) {
            
            Date nowDate = new Date();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm a"); 
            //원하는 데이터 포맷 지정
            String strNowDate = simpleDateFormat.format(nowDate);
            String addTimeMsg = msg.getValue() + "\t\t" + strNowDate;
            
            
          // 메시지 보내기
          sendMessage(msg.getBuyerId(), addTimeMsg);
          
          if(avo != null) {
          //알람 업데이트
          alarmservice.updateAlarmCnt(avo.getAlarm_id());
          }
          
          // 파일에 저장하기
          saveFile(msg.getBuyerId(), addTimeMsg, chatId);
        }
      }
    }

    // 채팅 내용을 파일로 부터 읽어온다.
    private String readFile(String chatId) {
      // d드라이브의 chat 폴더의 chat 파일
      File file = new File(chatId);
      // 파일 있는지 검사
      if (!file.exists()) {
        return "";
      }
      // 파일을 읽어온다.
      try(InputStream stream = new FileInputStream(file)) {
          byte[] buffer = new byte[(int) file.length()];
          stream.read(buffer);
          return new String(buffer);
      } catch (Throwable e) {
        e.printStackTrace();
        return "";
      }
    }
    // 파일를 저장하는 함수
    private void saveFile(String id, String message, String chatId) {
      // 메시지 내용
            //지정한 포맷으로 변환 
        String msg = id + ":  " + message + "\n";
      // 파일을 저장한다.
      try (FileOutputStream stream = new FileOutputStream(chatId, true)) {
        stream.write(msg.getBytes("UTF-8"));
      } catch (Throwable e) {
        e.printStackTrace();
      }
    }
    // 메시지 보내기는 함수
    private void sendMessage(String id, String message) {
      // 메시지 내용
      String sendMessage = id + ":  " + message + "\n";
      for (ChatSessionVO user : users) {
        try {
          // 메시지 전송
          user.getSession().getBasicRemote().sendText(sendMessage);
        } catch (Throwable e) {
          e.printStackTrace();
        }
      }
    }
    // WebSocket이 닫기면 호출되는 함수
    @OnClose
    public void handleClose(Session userSession) {
      // session으로 users에서 찾는다.
      Optional<ChatSessionVO> session = users.stream().filter(x -> x.getSession() == userSession).findFirst();
      // 있으면 삭제
      if (session.isPresent()) {
        users.remove(session.get());
      }
    }

}
