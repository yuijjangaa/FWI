package chat.Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import chat.Service.ChatServiceImpl;
import chat.Service.IChatService;
import chat.VO.ChatVO;
import chat.VO.TradeVO;
import prodboard.Service.IProdBoardService;
import prodboard.Service.ProdBoardServiceImpl;

@WebServlet("/chatUpdate.do")
public class ChatUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    request.setCharacterEncoding("utf-8");
	    response.setCharacterEncoding("utf-8");
	    
	    IChatService chatService = ChatServiceImpl.getInstance();
	    IProdBoardService prodService = ProdBoardServiceImpl.getService();
	    
	    String id = request.getParameter("Id");
	    String prodId = request.getParameter("prodId");
	    
	    ChatVO vo = new ChatVO();
	    vo.setMem_id(id);
	    vo.setProd_id(prodId);
	    
	    TradeVO tradeVO = chatService.getTrade(prodId);
	    // 삭제 테이블로 이동
	    int res = chatService.insertTrade(tradeVO);
	    // 게시글 삭제
	    int cnt = 0;
	    if(res>0) {
	        prodService.deleteProdById(prodId);
	        cnt = chatService.updateChatStatus(vo);
	    }
	    
	    request.setAttribute("result", cnt);
	    request.getRequestDispatcher("/chatview/result.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
