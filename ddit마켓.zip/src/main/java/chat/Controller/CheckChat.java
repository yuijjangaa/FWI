package chat.Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import alarm.Service.AlarmServiceImpl;
import alarm.Service.IAlarmService;
import alarm.VO.AlarmVO;
import chat.Service.ChatServiceImpl;
import chat.Service.IChatService;
import chat.VO.ChatVO;

@WebServlet("/CheckChat.do")
public class CheckChat extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    request.setCharacterEncoding("utf-8");
	    response.setCharacterEncoding("utf-8");
	    
	    HttpSession session = request.getSession();
	    String id = (String) session.getAttribute("userId");
	    String chatId = request.getParameter("chatId");
	    String prodId = request.getParameter("prodId");
	    
	    ChatVO vo = new ChatVO();
	    vo.setMem_id(id);
	    vo.setProd_id(prodId);
	    
	    IChatService chatService = ChatServiceImpl.getInstance();
	    IAlarmService alarmService = AlarmServiceImpl.getInstance();
	    
	    ChatVO chatVO = chatService.getChatById(chatId);
	    
	    String chatIdCheck = chatService.getChatId(vo);
	    ChatVO chatVO2 = chatService.getChatById(chatIdCheck);
	    
	    if(chatVO != null && chatVO.getChat_status().equals("Y")) {
	        // 여기서 알람 초기화
	        AlarmVO avo = alarmService.checkAlarm(chatVO.getChat_id());
	        alarmService.resetAlarmCnt(avo.getAlarm_id());
	        request.getRequestDispatcher("/chat/Chatting.jsp?prodId=" + prodId).forward(request, response);
//	        request.getRequestDispatcher("/chat/Chatting.jsp?chatId=" + chatId).forward(request, response);
	    } else if(chatVO2 != null && chatVO2.getChat_status().equals("N")) {
	        request.getRequestDispatcher("/chat/endChat.jsp?prodId=" + prodId).forward(request, response);
//	        request.getRequestDispatcher("/chat/endChat.jsp?chatId=" + chatId).forward(request, response);
	    } else {
	        request.getRequestDispatcher("/chat/Chatting.jsp?prodId=" + prodId).forward(request, response);
//	        request.getRequestDispatcher("/chat/Chatting.jsp?chatId=" + chatId).forward(request, response);
	    }
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
