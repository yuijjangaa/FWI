package chat.Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import chat.Service.ChatServiceImpl;
import chat.Service.IChatService;
import chat.VO.ChatVO;

@WebServlet("/ChatContent.do")
public class ChatContent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    request.setCharacterEncoding("utf-8");
	    response.setCharacterEncoding("utf-8");
	    
	    HttpSession session = request.getSession();
	    String memId = (String) session.getAttribute("userId");
	    String prodId = request.getParameter("prodId");
	    
	    IChatService chatService = ChatServiceImpl.getInstance();
	    ChatVO chatVO = new ChatVO();
	    chatVO.setMem_id(memId);
	    chatVO.setProd_id(prodId);
	    
	    ChatVO vo = chatService.getChatEnd(chatVO);
	    
	    request.setAttribute("ChatVO", vo);
	    request.getRequestDispatcher("/chatview/chatstatus.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
