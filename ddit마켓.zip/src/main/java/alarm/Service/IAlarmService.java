package alarm.Service;

import java.util.List;
import java.util.Map;

import alarm.VO.AlarmVO;
import chat.VO.AlarmListVO;

public interface IAlarmService {
    public int newAlarm(String chatId);
    
    public int updateAlarmCnt(int alarmId);
    
    public int resetAlarmCnt(int alarmId);
    
    public AlarmVO checkAlarm(String chatId);
    
    public List<AlarmListVO> getAlarmList(String id);
}
