package alarm.Service;

import java.util.List;

import alarm.Dao.AlarmDaoImpl;
import alarm.Dao.IAlarmDao;
import alarm.VO.AlarmVO;
import chat.VO.AlarmListVO;

public class AlarmServiceImpl implements IAlarmService {
    private static AlarmServiceImpl service;
    private static IAlarmDao dao;
    
    private AlarmServiceImpl() {
        dao = AlarmDaoImpl.getInstance();
    }
    
    public static AlarmServiceImpl getInstance() {
        if(service == null) service = new AlarmServiceImpl();
        return service;
    }

    @Override
    public int newAlarm(String chatId) {
        return dao.newAlarm(chatId);
    }

    @Override
    public int updateAlarmCnt(int alarmId) {
        return dao.updateAlarmCnt(alarmId);
    }

    @Override
    public int resetAlarmCnt(int alarmId) {
        return dao.resetAlarmCnt(alarmId);
    }

    @Override
    public AlarmVO checkAlarm(String chatId) {
        return dao.checkAlarm(chatId);
    }

    @Override
    public List<AlarmListVO> getAlarmList(String id) {
        return dao.getAlarmList(id);
    }


}
