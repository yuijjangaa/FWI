package alarm.VO;

public class AlarmVO {
    private int alarm_id;
    private String chat_id;
    private int alarm_cnt;
    
    
    public int getAlarm_id() {
        return alarm_id;
    }
    public void setAlarm_id(int alarm_id) {
        this.alarm_id = alarm_id;
    }
    public String getChat_id() {
        return chat_id;
    }
    public void setChat_id(String chat_id) {
        this.chat_id = chat_id;
    }
    public int getAlarm_cnt() {
        return alarm_cnt;
    }
    public void setAlarm_cnt(int alarm_cnt) {
        this.alarm_cnt = alarm_cnt;
    }

}
