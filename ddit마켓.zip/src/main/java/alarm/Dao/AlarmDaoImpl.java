package alarm.Dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import Util.mybatisSqlSessionFactory;
import alarm.VO.AlarmVO;
import chat.VO.AlarmListVO;

public class AlarmDaoImpl implements IAlarmDao {
    private static AlarmDaoImpl dao;
    
    private AlarmDaoImpl() {
    }
    
    public static AlarmDaoImpl getInstance() {
        if(dao == null) dao = new AlarmDaoImpl();
        return dao;
    }

    @Override
    public int newAlarm(String chatId) {
        SqlSession session = null;
        int cnt = 0;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            cnt = session.insert("alarm.newAlarm", chatId);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.commit();
            session.close();
        }
        return cnt;
    }

    @Override
    public int updateAlarmCnt(int alarmId) {
        SqlSession session = null;
        int cnt = 0;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            cnt = session.insert("alarm.updateAlarmCnt", alarmId);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.commit();
            session.close();
        }
        return cnt;
    }

    @Override
    public int resetAlarmCnt(int alarmId) {
        SqlSession session = null;
        int cnt = 0;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            cnt = session.insert("alarm.resetAlarmCnt", alarmId);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.commit();
            session.close();
        }
        return cnt;
    }

    @Override
    public AlarmVO checkAlarm(String chatId) {
        SqlSession session = null;
        AlarmVO vo = null;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            vo = session.selectOne("alarm.checkAlarm", chatId);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return vo;
    }

    @Override
    public List<AlarmListVO> getAlarmList(String id) {
        SqlSession session = null;
        List<AlarmListVO> list = null;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            list = session.selectList("alarm.getAlarmList", id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

}
