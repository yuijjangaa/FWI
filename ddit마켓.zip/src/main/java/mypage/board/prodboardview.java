package mypage.board;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Free.VO.FreeVO;
import Member.Service.IMemberService;
import Member.Service.MemberServiceImpl;
import prodboard.VO.ProdVO;


@WebServlet("/member/prodboardview.do")
public class prodboardview extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String memId = request.getParameter("mem_id");
		
		IMemberService service = MemberServiceImpl.getInstance();
		List<ProdVO> pepVo = service.prodboardlist(memId);
		
		request.setAttribute("mem_id", pepVo);
		request.getRequestDispatcher("/MyPage/prodview.jsp").forward(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
