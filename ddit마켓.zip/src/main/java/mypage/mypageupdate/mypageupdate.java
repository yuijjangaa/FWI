package mypage.mypageupdate;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Member.Service.IMemberService;
import Member.Service.MemberServiceImpl;
import Member.VO.MemberVO;


@WebServlet("/mypage/memberUpdate.do")
public class mypageupdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		String memId = request.getParameter("mem_id");
		
		IMemberService service = MemberServiceImpl.getInstance();
		MemberVO memVo = service.getMemberId(memId);
		
		request.setAttribute("mem_id", memVo);
		
		request.getRequestDispatcher("/MyPage/mypageUpdate.jsp").forward(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		//System.out.println("넘어가라");
		String memId = request.getParameter("mem_id");
		String memname = request.getParameter("my_name");
		String membirth = request.getParameter("my_birth");
		String memPass = request.getParameter("my_pass");
		String memAddr = request.getParameter("my_addr");
		String memMail = request.getParameter("my_mail");
		String memAddr2 = request.getParameter("memaddr");
		
		MemberVO memVo = new MemberVO();
		

		memVo.setMem_id(memId);
		memVo.setMem_name(memname);
		memVo.setMem_birth(membirth);
		memVo.setMem_password(memPass);
		memVo.setMem_address(memAddr2 ==null ? memAddr : memAddr + " " + memAddr2);
		memVo.setMem_email(memMail);
		
		IMemberService service = MemberServiceImpl.getInstance();
		service.updatemypage(memVo);
		
		response.sendRedirect(request.getContextPath() + "/main/main.jsp");
		
	}

}
