package prodboard.Dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import Util.mybatisSqlSessionFactory;
import prodboard.VO.ProdBoardMainVO;
import prodboard.VO.ProdBoardVO;
import prodboard.VO.ProdFilesVO;
import prodboard.VO.ProdInfoVO;
import prodboard.VO.ProdVO;
import prodboard.VO.ProdWishlistVO;

public class ProdBoardDaoImpl implements IProdBoardDao {
	private static ProdBoardDaoImpl dao;

	public ProdBoardDaoImpl() {};

	public static ProdBoardDaoImpl getDao() {
		if (dao == null) {
			dao = new ProdBoardDaoImpl();
		}

		return dao;
	}
	
	@Override
	public int insertProd(ProdVO vo) {
		// TODO Auto-generated method stub
		int cnt = 0;
		SqlSession session = null;
		
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.insert("prodboard.insertProd", vo);
		} 
		finally {
			 if (session != null) {
				 session.commit();
			     session.close();
			 }
		}
		return cnt;
	}

	@Override
	public int insertProdBoard(ProdBoardVO bvo) {
		// TODO Auto-generated method stub
		int cnt = 0;
		SqlSession session = null;
		
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.insert("prodboard.insertProdBoard", bvo);
		} 
		finally {
			 if (session != null) {
				 session.commit();
			     session.close();
			 }
		}
		return cnt;
	}
	
	@Override
	public String uploadGetId() {
		// TODO Auto-generated method stub
		String value = null;
		SqlSession session = null;
		
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			value = session.selectOne("prodboard.uploadGetId");
		} 
		finally {
			 if (session != null) {
				 session.commit();
			     session.close();
			 }
		}
		return value;
	}

	@Override
	public int insertFilesUpload(ProdFilesVO vo) {
		// TODO Auto-generated method stub
		int cnt = 0;
		SqlSession session = null;
		
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.insert("prodboard.insertFilesUpload", vo);
		} 
		finally {
			 if (session != null) {
				 session.commit();
			     session.close();
			 }
		}
		return cnt;
	}

	@Override
	public List<ProdBoardMainVO> prodBoardMain() {
		// TODO Auto-generated method stub
		List<ProdBoardMainVO> list = null;
		SqlSession session = mybatisSqlSessionFactory.getSqlSession();

		try {
			list = session.selectList("prodboard.prodBoardMain");
		} finally {
			// TODO: handle finally clause
			session.commit();
			session.close();
		}

		return list;
	}

	@Override
	public List<ProdFilesVO> getImagesByProdId(String prod_id) {
		// TODO Auto-generated method stub
		List<ProdFilesVO> list = null;
		SqlSession session = mybatisSqlSessionFactory.getSqlSession();

		try {
			list = session.selectList("prodboard.getImagesByProdId", prod_id);
		} finally {
			// TODO: handle finally clause
			session.commit();
			session.close();
		}

		return list;
	}

	@Override
	public ProdInfoVO selectProdById(String mem_id) {
		// TODO Auto-generated method stub
		ProdInfoVO vo = null;
		SqlSession session = mybatisSqlSessionFactory.getSqlSession();
		
		try {
			vo = session.selectOne("prodboard.selectProdById", mem_id);
		} finally {
			// TODO: handle finally clause
			session.commit();
			session.close();
		}
		
		return vo;
	}

	@Override
	public int deleteProdById(String prod_id) {
		// TODO Auto-generated method stub
		int cnt = 0;
		SqlSession session = null;
		
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.delete("prodboard.deleteProdById", prod_id);
		} 
		finally {
			 if (session != null) {
				 session.commit();
			     session.close();
			 }
		}
		return cnt;
	}

	@Override
	public int updateProdById(ProdVO vo) {
		// TODO Auto-generated method stub
		int cnt = 0;
		SqlSession session = null;

		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.insert("prodboard.updateProdById", vo);
		} finally {
			if (session != null) {
				session.commit();
				session.close();
			}
		}
		return cnt;
	}

	@Override
	public int deleteProdFilesById(String prod_id) {
		// TODO Auto-generated method stub
		int cnt = 0;
		SqlSession session = null;
		
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.delete("prodboard.deleteProdFilesById", prod_id);
		} 
		finally {
			 if (session != null) {
				 session.commit();
			     session.close();
			 }
		}
		return cnt;
	}

	@Override
	public ProdVO getProdById(String prod_id) {
		// TODO Auto-generated method stub
		ProdVO vo = null;
		SqlSession session = null;

		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			vo = session.selectOne("prodboard.getProdById", prod_id);
		} finally {
			if (session != null) {
				session.commit();
				session.close();
			}
		}
		return vo;
	}

	@Override
	public List<ProdBoardMainVO> prodBoardMainById(String categories_id) {
		// TODO Auto-generated method stub
		List<ProdBoardMainVO> list = null;
		SqlSession session = mybatisSqlSessionFactory.getSqlSession();

		try {
			list = session.selectList("prodboard.prodBoardMainById", categories_id);
		} finally {
			// TODO: handle finally clause
			session.commit();
			session.close();
		}

		return list;
	}

	@Override
	public List<ProdBoardMainVO> prodBoardMainBySearch(String searchKeyword) {
		// TODO Auto-generated method stub
		List<ProdBoardMainVO> list = null;
		SqlSession session = mybatisSqlSessionFactory.getSqlSession();

		try {
			list = session.selectList("prodboard.prodBoardMainBySearch", searchKeyword);
		} finally {
			// TODO: handle finally clause
			session.commit();
			session.close();
		}

		return list;
	}

	@Override
	public int updateViewsById(String prod_id) {
		// TODO Auto-generated method stub
		int cnt = 0;
		SqlSession session = null;
		
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.delete("prodboard.updateViewsById", prod_id);
		} 
		finally {
			 if (session != null) {
				 session.commit();
			     session.close();
			 }
		}
		return cnt;
	}

	@Override
	public int insertWishlist(ProdWishlistVO wvo) {
		// TODO Auto-generated method stub
		int cnt = 0;
		SqlSession session = null;
		
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.insert("prodboard.insertWishlist", wvo);
		} 
		finally {
			 if (session != null) {
				 session.commit();
			     session.close();
			 }
		}
		return cnt;
	}

	@Override
	public int selectProdWishById(String wish_id) {
		// TODO Auto-generated method stub
		int cnt = 0;
		SqlSession session = null;
		
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.selectOne("prodboard.selectProdWishById", wish_id);
		} 
		finally {
			 if (session != null) {
				 session.commit();
			     session.close();
			 }
		}
		return cnt;
	}

	@Override
	public int deleteWishlist(String wish_id) {
		// TODO Auto-generated method stub
		int cnt = 0;
		SqlSession session = null;
		
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.delete("prodboard.deleteWishlist", wish_id);
		} 
		finally {
			 if (session != null) {
				 session.commit();
			     session.close();
			 }
		}
		return cnt;
	}

	@Override
	public int updateProdGreatsPlus(String prod_id) {
		// TODO Auto-generated method stub
		int cnt = 0;
		SqlSession session = null;
		
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.delete("prodboard.updateProdGreatsPlus", prod_id);
		} 
		finally {
			 if (session != null) {
				 session.commit();
			     session.close();
			 }
		}
		return cnt;
	}

	@Override
	public int updateProdGreatsMinus(String prod_id) {
		// TODO Auto-generated method stub
		int cnt = 0;
		SqlSession session = null;
		
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.delete("prodboard.updateProdGreatsMinus", prod_id);
		} 
		finally {
			 if (session != null) {
				 session.commit();
			     session.close();
			 }
		}
		return cnt;
	}

	@Override
	public List<ProdBoardMainVO> selectTopProducts() {
		// TODO Auto-generated method stub
		List<ProdBoardMainVO> list = null;
		SqlSession session = mybatisSqlSessionFactory.getSqlSession();

		try {
			list = session.selectList("prodboard.selectTopProducts");
		} finally {
			// TODO: handle finally clause
			session.commit();
			session.close();
		}

		return list;
	}

	@Override
	public List<ProdBoardMainVO> prodBoardWishListById(String mem_id) {
		// TODO Auto-generated method stub
		List<ProdBoardMainVO> list = null;
		SqlSession session = mybatisSqlSessionFactory.getSqlSession();

		try {
			list = session.selectList("prodboard.prodBoardWishListById", mem_id);
		} finally {
			// TODO: handle finally clause
			session.commit();
			session.close();
		}

		return list;
	}

}
