package prodboard.Dao;

import java.util.List;

import prodboard.VO.ProdBoardMainVO;
import prodboard.VO.ProdBoardVO;
import prodboard.VO.ProdFilesVO;
import prodboard.VO.ProdInfoVO;
import prodboard.VO.ProdVO;
import prodboard.VO.ProdWishlistVO;

public interface IProdBoardDao {
	// prodBoard 정보 불러오기 -> main
	public List<ProdBoardMainVO> prodBoardMain();
	
	// prodBoard Top 출력하기
	public List<ProdBoardMainVO> selectTopProducts();
	
	// 카테고리별로 정렬하는 메서드
	public List<ProdBoardMainVO> prodBoardMainById(String categories_id);
	
	// 검색으로 정렬하는 메서드
	public List<ProdBoardMainVO> prodBoardMainBySearch(String searchKeyword);
	
	// 마이페이지에 띄울 위시리스트 -> memId를 받음
	public List<ProdBoardMainVO> prodBoardWishListById(String mem_id);
	
	// 물품 등록 메서드
	public int insertProd(ProdVO vo);
	
	// 물품게시판 등록 메서드
	public int insertProdBoard(ProdBoardVO bvo);
	
	// 이미지 등록을 위한 현재 등록되는 물품 ID 조회하는 메서드
	public String uploadGetId();
	
	// 이미지 업로드
	public int insertFilesUpload(ProdFilesVO vo);
	
	// prod_id에 해당하는 image 들을 저장하는 메서드
	public List<ProdFilesVO> getImagesByProdId(String prod_id);
	
	// prod_id에 해당하는 prodInfo 들을 저장하는 메서드
	public ProdInfoVO selectProdById(String mem_id);
	
	// prod_id에 해당하는 prod -> 물품 게시판을 제거하는 메서드
	public int deleteProdById(String prod_id);
	
	// prod_id에 해당하는 상세 물건을 업데이트하는 메서드
	public int  updateProdById(ProdVO vo);
	
	// prod_id에 해당하는 prodfiles -> 이미지 재 업로드를 하기 위한 파일 지우기
	public int deleteProdFilesById(String prod_id);
	
	// prod_id에 해당하는 prodVo -> 상품 수정할 때 value값 가지고 온다.
	public ProdVO getProdById(String prod_id);
	
	// prod_id에 해당하는 prodBoard Views 증가
	public int updateViewsById(String prod_id);
	
	// 찜하기 기능을 눌렀을 때 insert하는 메서드
	public int insertWishlist(ProdWishlistVO wvo);
	
	// 찜하기를 했는지 확인하는 메서드
	public int selectProdWishById(String wish_id);
	
	// 찜기능 해제
	public int deleteWishlist(String wish_id);
	
	// 찜하면 하트 수 증가 메서드
	public int updateProdGreatsPlus(String prod_id);
	
	// 찜하면 하트 수 마이너스 메서드
	public int updateProdGreatsMinus(String prod_id);
}
