package prodboard.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import prodboard.Service.IProdBoardService;
import prodboard.Service.ProdBoardServiceImpl;
import prodboard.VO.ProdBoardMainVO;

/**
 * Servlet implementation class ProdWishListMyPage
 */
@WebServlet("/prodWishListMyPage.do")
public class ProdWishListMyPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);

		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		IProdBoardService service = ProdBoardServiceImpl.getService();
		
		String userId = request.getParameter("userId");
		System.out.println(userId);
		
		List<ProdBoardMainVO> list = service.prodBoardWishListById(userId);
		
		request.setAttribute("listvalue", list);
		
		request.getRequestDispatcher("/prodboardview/ProdBoardList.jsp").forward(request, response);
	}

}
