package prodboard.Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import prodboard.Service.IProdBoardService;
import prodboard.Service.ProdBoardServiceImpl;
import prodboard.VO.ProdBoardVO;

/**
 * Servlet implementation class ProdInsert
 */
@WebServlet("/prodBoardInsert.do")
public class ProdBoardInsert extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		String userId = request.getParameter("userId");
		String prodId = request.getParameter("prodId");
		
		//System.out.println(" userID : " + userId + " prodId " + prodId);
		
		ProdBoardVO bvo = new ProdBoardVO();
		bvo.setMem_id(userId);
		bvo.setProd_id(prodId);
		
		IProdBoardService service = ProdBoardServiceImpl.getService();
		
		int cnt = service.insertProdBoard(bvo);
		
		request.setAttribute("cnt", cnt);
		
		request.getRequestDispatcher("/prodboardview/result.jsp").forward(request, response);
		
		//response.sendRedirect(request.getContextPath() + "/ProdBoard/ProdBoard.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		
	}

}
