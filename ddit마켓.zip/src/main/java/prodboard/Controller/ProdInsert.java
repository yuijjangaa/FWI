package prodboard.Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import prodboard.Service.IProdBoardService;
import prodboard.Service.ProdBoardServiceImpl;
import prodboard.VO.ProdBoardVO;
import prodboard.VO.ProdVO;

/**
 * Servlet implementation class ProdInsert
 */
@WebServlet("/prodInsert.do")
public class ProdInsert extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		//String rdata = request.getParameter("rdata");
		String userId = request.getParameter("userId");
		
		//System.out.println("이름" + request.getParameter("productName") + "가격" + Integer.parseInt(request.getParameter("productPrice")) + "카테고리" + 
				//request.getParameter("category") + "거래지역" + request.getParameter("tradingArea") + "상태" + request.getParameter("productStatus") +  "정보" + request.getParameter("productDetail"));
		
		ProdVO vo = new ProdVO();
		vo.setMem_id(userId);
		vo.setProd_name(request.getParameter("productName"));
		vo.setProd_price(Integer.parseInt(request.getParameter("productPrice")));
		vo.setCategories_id(request.getParameter("category"));
		vo.setProd_area(request.getParameter("tradingArea"));
		vo.setProd_status(request.getParameter("productStatus"));
		vo.setProd_description(request.getParameter("productDetail"));
		
		IProdBoardService service = ProdBoardServiceImpl.getService();
		
		int cnt = service.insertProd(vo);
		
		request.setAttribute("cnt", cnt);
		
		request.getRequestDispatcher("/prodboardview/result.jsp").forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		
	}

}
