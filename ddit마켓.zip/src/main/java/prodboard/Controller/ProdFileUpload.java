package prodboard.Controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import prodboard.Service.IProdBoardService;
import prodboard.Service.ProdBoardServiceImpl;
import prodboard.VO.ProdFilesVO;

/**
 * Servlet implementation class ProdFileUpload
 */
@WebServlet("/prodFileUpload.do")
@MultipartConfig(
		fileSizeThreshold = 1024 * 1024 * 10, maxFileSize = 1024 * 1024 * 30,
		maxRequestSize = 1024 * 1024 * 100
		)
public class ProdFileUpload extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		String prodId = request.getParameter("prodId");
		//System.out.println("ProdFileUpload.java -> servlet check" + prodId);
		
		String uploadPath = request.getServletContext().getRealPath("/") + "uploadFiles";
		System.out.println(uploadPath);
		//String uploadPath = "D:/D_Other/uploadFiles/test";
		
		File f = new File(uploadPath);
		if (!f.exists()) {
			f.mkdirs();
		}
		
		// 파일명 저장
		String fileName = "";
		List<ProdFilesVO> fileList = new ArrayList<>();
		
		int imageSeq = 1;
		for (Part part : request.getParts()) {
			fileName = extractFileName(part);
			System.out.println("Extracted file name: " + fileName);
			
			// 1개의 Upload파일에 대한 정보를 저장하기 위한 VO객체 생성
			ProdFilesVO vo = new ProdFilesVO();
			
			//현재 등록한 prodId 저장
			vo.setProd_id(prodId);
			
			String imageName = prodId + "_" + imageSeq + "_" + fileName;
			vo.setProd_image(imageName);
			
			try {
				// part.write() 메서드 -> Upload된 파일을 저장하는 메서드
				//System.out.println("File saved to: " + uploadPath + File.separator + imageName);
				part.write(uploadPath + File.separator + imageName); // 파일 저장하기...
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			fileList.add(vo);
			imageSeq++;
			/*
			 * if (!"".equals(fileName)) { // 파일인지 검사 }
			 */
		}
		
		// 반복문이 끝나면 List에 저장된 파일 정보를 DB에 insert
		IProdBoardService service = ProdBoardServiceImpl.getService();

		for (ProdFilesVO filesVO : fileList) {
			service.insertFilesUpload(filesVO);
		}
		
		
		response.sendRedirect(request.getContextPath() + "/ProdBoard/ProdBoard.jsp");
	}
	
	private String extractFileName(Part part) {
		String fileName = "";	// 반환할 파일명이 저장될 변수
		String headerValue = part.getHeader("content-disposition"); // 헤더의 '키값'을 이용하여 값을 구한다.
		
		String[] items = headerValue.split(";");
		for (String item : items) {
			if (item.trim().startsWith("filename")) {
				fileName = item.substring(item.indexOf("=") + 2, item.length() - 1);
			}
		}
		
		return fileName;
	}

}
