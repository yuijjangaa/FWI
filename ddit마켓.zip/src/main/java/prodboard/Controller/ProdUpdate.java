package prodboard.Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import prodboard.Service.IProdBoardService;
import prodboard.Service.ProdBoardServiceImpl;
import prodboard.VO.ProdVO;

/**
 * Servlet implementation class ProdUpdate
 */
@WebServlet("/prodUpdate.do")
public class ProdUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		//String rdata = request.getParameter("rdata");
		// String userId = request.getParameter("userId");
		String prodId = request.getParameter("prodId");
		
		System.out.println("Update Prod_Id check -> " + prodId);
		
		ProdVO vo = new ProdVO();
		vo.setCategories_id(request.getParameter("category"));
		vo.setProd_name(request.getParameter("productName"));
		vo.setProd_price(Integer.parseInt(request.getParameter("productPrice")));
		vo.setProd_description(request.getParameter("productDetail"));
		vo.setProd_area(request.getParameter("tradingArea"));
		vo.setProd_status(request.getParameter("productStatus"));
		vo.setProd_id(prodId);
		
		IProdBoardService service = ProdBoardServiceImpl.getService();
		
		int cnt = service.updateProdById(vo);
		
		request.setAttribute("cnt", cnt);
		
		request.getRequestDispatcher("/prodboardview/result.jsp").forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
	}

}
