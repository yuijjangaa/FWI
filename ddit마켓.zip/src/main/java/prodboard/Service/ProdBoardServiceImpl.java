package prodboard.Service;

import java.util.List;

import prodboard.Dao.IProdBoardDao;
import prodboard.Dao.ProdBoardDaoImpl;
import prodboard.VO.ProdBoardMainVO;
import prodboard.VO.ProdBoardVO;
import prodboard.VO.ProdFilesVO;
import prodboard.VO.ProdInfoVO;
import prodboard.VO.ProdVO;
import prodboard.VO.ProdWishlistVO;

public class ProdBoardServiceImpl implements IProdBoardService {
	private IProdBoardDao dao;
	private static ProdBoardServiceImpl Service;
	
	public ProdBoardServiceImpl() {
		dao = ProdBoardDaoImpl.getDao();
	};
	
	public static ProdBoardServiceImpl getService() {
		if (Service == null) 
			Service = new ProdBoardServiceImpl();
		
		return Service;
	}
	
	@Override
	public int insertProd(ProdVO vo) {
		// TODO Auto-generated method stub
		return dao.insertProd(vo);
	}

	@Override
	public int insertProdBoard(ProdBoardVO bvo) {
		// TODO Auto-generated method stub
		return dao.insertProdBoard(bvo);
	}
	
	@Override
	public String uploadGetId() {
		// TODO Auto-generated method stub
		return dao.uploadGetId();
	}

	@Override
	public int insertFilesUpload(ProdFilesVO vo) {
		// TODO Auto-generated method stub
		return dao.insertFilesUpload(vo);
	}

	@Override
	public List<ProdBoardMainVO> prodBoardMain() {
		// TODO Auto-generated method stub
		return dao.prodBoardMain();
	}

	@Override
	public List<ProdFilesVO> getImagesByProdId(String prod_id) {
		// TODO Auto-generated method stub
		return dao.getImagesByProdId(prod_id);
	}

	@Override
	public ProdInfoVO selectProdById(String mem_id) {
		// TODO Auto-generated method stub
		return dao.selectProdById(mem_id);
	}

	@Override
	public int deleteProdById(String prod_id) {
		// TODO Auto-generated method stub
		return dao.deleteProdById(prod_id);
	}

	@Override
	public int updateProdById(ProdVO vo) {
		// TODO Auto-generated method stub
		return dao.updateProdById(vo);
	}

	@Override
	public int deleteProdFilesById(String prod_id) {
		// TODO Auto-generated method stub
		return dao.deleteProdFilesById(prod_id);
	}

	@Override
	public ProdVO getProdById(String prod_id) {
		// TODO Auto-generated method stub
		return dao.getProdById(prod_id);
	}

	@Override
	public List<ProdBoardMainVO> prodBoardMainById(String categories_id) {
		// TODO Auto-generated method stub
		return dao.prodBoardMainById(categories_id);
	}

	@Override
	public List<ProdBoardMainVO> prodBoardMainBySearch(String searchKeyword) {
		// TODO Auto-generated method stub
		return dao.prodBoardMainBySearch(searchKeyword);
	}

	@Override
	public int updateViewsById(String prod_id) {
		// TODO Auto-generated method stub
		return dao.updateViewsById(prod_id);
	}

	@Override
	public int insertWishlist(ProdWishlistVO wvo) {
		// TODO Auto-generated method stub
		return dao.insertWishlist(wvo);
	}

	@Override
	public int selectProdWishById(String wish_id) {
		// TODO Auto-generated method stub
		return dao.selectProdWishById(wish_id);
	}

	@Override
	public int deleteWishlist(String wish_id) {
		// TODO Auto-generated method stub
		return dao.deleteWishlist(wish_id);
	}

	@Override
	public int updateProdGreatsPlus(String prod_id) {
		// TODO Auto-generated method stub
		return dao.updateProdGreatsPlus(prod_id);
	}

	@Override
	public int updateProdGreatsMinus(String prod_id) {
		// TODO Auto-generated method stub
		return dao.updateProdGreatsMinus(prod_id);
	}

	@Override
	public List<ProdBoardMainVO> selectTopProducts() {
		// TODO Auto-generated method stub
		return dao.selectTopProducts();
	}

	@Override
	public List<ProdBoardMainVO> prodBoardWishListById(String mem_id) {
		// TODO Auto-generated method stub
		return dao.prodBoardWishListById(mem_id);
	}

	

}
