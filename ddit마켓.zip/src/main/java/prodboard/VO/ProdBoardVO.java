package prodboard.VO;

public class ProdBoardVO {
	private String prodboard_id;
	private String mem_id;
	private String prod_id;
	private String pb_createdate;
	private int pb_views;
	private String pb_reportcont;
	private int pb_reportstatus;
	
	public String getProdboard_id() {
		return prodboard_id;
	}
	public void setProdboard_id(String prodboard_id) {
		this.prodboard_id = prodboard_id;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getProd_id() {
		return prod_id;
	}
	public void setProd_id(String prod_id) {
		this.prod_id = prod_id;
	}
	public String getPb_createdate() {
		return pb_createdate;
	}
	public void setPb_createdate(String pb_createdate) {
		this.pb_createdate = pb_createdate;
	}
	public int getPb_views() {
		return pb_views;
	}
	public void setPb_views(int pb_views) {
		this.pb_views = pb_views;
	}
	public String getPb_reportcont() {
		return pb_reportcont;
	}
	public void setPb_reportcont(String pb_reportcont) {
		this.pb_reportcont = pb_reportcont;
	}
	public int getPb_reportstatus() {
		return pb_reportstatus;
	}
	public void setPb_reportstatus(int pb_reportstatus) {
		this.pb_reportstatus = pb_reportstatus;
	}
	
}
