package prodboard.VO;

public class ProdInfoVO {
	private String prod_id;
	private String mem_id;
	private String categories_id;
	private String mem_nickname;
	private String prod_name;
	private int prod_price;
	private String prod_area;
	private String prod_status;
	private String prod_description;
	private int pb_views;
	private String created_time_ago;
	private int pb_greats;
	
	public int getPb_greats() {
		return pb_greats;
	}
	public void setPb_greats(int pb_greats) {
		this.pb_greats = pb_greats;
	}
	public String getCreated_time_ago() {
		return created_time_ago;
	}
	public void setCreated_time_ago(String created_time_ago) {
		this.created_time_ago = created_time_ago;
	}
	public String getProd_id() {
		return prod_id;
	}
	public void setProd_id(String prod_id) {
		this.prod_id = prod_id;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getCategories_id() {
		return categories_id;
	}
	public void setCategories_id(String categories_id) {
		this.categories_id = categories_id;
	}
	public String getMem_nickname() {
		return mem_nickname;
	}
	public void setMem_nickname(String mem_nickname) {
		this.mem_nickname = mem_nickname;
	}
	public String getProd_name() {
		return prod_name;
	}
	public void setProd_name(String prod_name) {
		this.prod_name = prod_name;
	}
	public int getProd_price() {
		return prod_price;
	}
	public void setProd_price(int prod_price) {
		this.prod_price = prod_price;
	}
	public String getProd_area() {
		return prod_area;
	}
	public void setProd_area(String prod_area) {
		this.prod_area = prod_area;
	}
	public String getProd_status() {
		return prod_status;
	}
	public void setProd_status(String prod_status) {
		this.prod_status = prod_status;
	}
	public String getProd_description() {
		return prod_description;
	}
	public void setProd_description(String prod_description) {
		this.prod_description = prod_description;
	}
	public int getPb_views() {
		return pb_views;
	}
	public void setPb_views(int pb_views) {
		this.pb_views = pb_views;
	}
	
}
