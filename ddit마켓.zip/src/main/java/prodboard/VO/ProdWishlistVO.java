package prodboard.VO;

public class ProdWishlistVO {
	private String wish_id;
	private String mem_id;
	private String prod_id;
	private String created_at;
	
	public String getWish_id() {
		return wish_id;
	}
	public void setWish_id(String wish_id) {
		this.wish_id = wish_id;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getProd_id() {
		return prod_id;
	}
	public void setProd_id(String prod_id) {
		this.prod_id = prod_id;
	}
	public String getCreated_at() {
		return created_at;
	}
}
