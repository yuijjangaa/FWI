package Member.Dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import Free.VO.FreeVO;
import Member.VO.MemberVO;
import Util.mybatisSqlSessionFactory;
import prodboard.VO.ProdVO;

public class MemberDaoImpl implements IMemberDao{
    private static MemberDaoImpl dao;
    
    private MemberDaoImpl() {
    }
    
    public static MemberDaoImpl getInstance() {
        if(dao == null) dao = new MemberDaoImpl();
        return dao;
    }

    @Override
    public MemberVO getMemberId(String id) {
        SqlSession session = null;
        MemberVO vo = null;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            vo = session.selectOne("login.getMemberId", id);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return vo;
    }

    @Override
    public String getMember(MemberVO vo) {
        SqlSession session = null;
        String id = null;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            id = session.selectOne("login.getMember", vo);
        } finally {
            session.close();
        }
        return id;
    }

    @Override
    public int updatePass(MemberVO vo) {
        SqlSession session = null;
        int cnt = 0;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            cnt = session.update("login.updatePass", vo);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.commit();
            session.close();
        }
        return cnt;
    }
    
    @Override
    public List<MemberVO> getAllMember() {
        SqlSession session = null;
        List<MemberVO> memlist = null;
        
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            memlist = session.selectList("member.getAllMember");
            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if(session!=null) session.close();
        }
        return memlist;
    }



    @Override
    public int insertMember(MemberVO MemberVO) {
        SqlSession session = null;
        int cnt = 0;
        
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            cnt = session.insert("member.insertMember", MemberVO);
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            session.commit();
            session.close();
        }
        return cnt;
    }

    @Override
    public int checkID(String id) {
        SqlSession session = null;
        int cnt = 0;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            cnt = session.selectOne("member.checkID", id);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return cnt;
    }
    

    @Override
    public int updateMember(MemberVO vo) {
        SqlSession session = null;
        int cnt = 0;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            cnt = session.update("member.updateMember", vo);
            
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            session.commit();
            session.close();
        }
        return cnt;
    }
    
    @Override
    public MemberVO getDetail(String id) {
        SqlSession session = null;
        MemberVO vo = null;
        try {
            session = mybatisSqlSessionFactory.getSqlSession();
            vo = session.selectOne("member.getDetail", id);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return vo;
    }
    
    @Override
	public List<MemberVO> selectMemList(Map<String, Object> map) {
		SqlSession session = null;
		List<MemberVO> list = null;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			list = session.selectList("member.selectMemList", map);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		} return list;
    }

	@Override
	public int totalMemCount(Map<String, Object> map) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.selectOne("member.totalmemCount", map);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		} return cnt;
	}

	@Override
	public int updatemypage(MemberVO vo) {
		SqlSession session = mybatisSqlSessionFactory.getSqlSession();
		int cnt = 0;
		try {
			cnt = session.update("member.updatemypage", vo);
			if(cnt > 0)session.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(session!=null) session.close();
		}
		return cnt;
	}
	
	@Override
	   public List<FreeVO> freeboardlist(String id) {
	       SqlSession session = mybatisSqlSessionFactory.getSqlSession();
	       List<FreeVO> flist = null;
	       try {
	           flist = session.selectList("member.freeboard", id);
	       } catch (Exception e) {
	           e.printStackTrace();
	       } finally {
	           if(session != null) session.close();
	       }
	       return flist;
	   }
	
	@Override
	   public List<ProdVO> prodboardlist(String id) {
	      SqlSession session = mybatisSqlSessionFactory.getSqlSession();
	      List<ProdVO> plist = null;
	      try {
	         plist = session.selectList("member.prodboard", id);
	      }catch (Exception e) {
	         e.printStackTrace();
	      }finally {
	         if(session!=null) session.close();
	      }
	      return plist;
	   }

	@Override
    public List<MemberVO> getallblacklist() {
        SqlSession session = mybatisSqlSessionFactory.getSqlSession();
        List<MemberVO> list = null;
        try {
            list = session.selectList("member.blacklist");
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            if(session!=null) session.close();
        }
        return list;
    }
}