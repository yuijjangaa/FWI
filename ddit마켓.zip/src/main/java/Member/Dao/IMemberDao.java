package Member.Dao;

import java.util.List;
import java.util.Map;

import Anno.VO.AnnoVO;
import Free.VO.FreeVO;
import Member.VO.MemberVO;
import prodboard.VO.ProdVO;

public interface IMemberDao {
        /**
         * parameter로 받은 회원의 정보를 가져오는 메소드
         * @param id 조회할 회원 id
         * @return 해당 회원의 정보
         */
        public MemberVO getMemberId(String id);
        
        /**
         * 회원의 이름과 email 값을 받아 아이디를 가져오는 메소드
         * @param vo 이름과 email이 담긴 객체
         * @return 회원의 ID 가 담긴 vo
         */
        public String getMember(MemberVO vo);
        
        /**
         * 회원의 이름을 받아 해당 회원의 비밀번호를 변경
         * @param vo 전달받을 id값이 저장된 vo
         * @return 성공 : 1, 실패 : 0
         */
        public int updatePass(MemberVO vo);
        
        /**
         * member 테이블의 전체 데이터를 List에 담아서 반환하는 메서드
         * @return MemberVO가 저장된 List객체
         */
        public List<MemberVO> getAllMember();
        

        
         /**
         * MemberVO에 담겨진 자료를 DB에 insert하는 메서드
         * @param MemberVO insert할 데이터가 저장된 MemberVO객체
         * @return 작업 성공 : 1, 작업 실패 : 0
         */
        public int insertMember(MemberVO MemberVO);
        
        /**
         * 회원ID를 인수값으로 받아서 해당 회원ID의 개수를 반환하는 메서드
         * 
         * @param id 검색할 회원ID
         * @return 검색된 회원ID의 개수
         */
        public int checkID(String id);
        
        /**
         * MemberVO자료를 이용하여 DB에 update하는 메서드
         * @param vo update할 회원 정보가 저장된 MemberVO객체
         * @return 작업 성공 : 1, 작업 실패 : 0
         */
        public int updateMember(MemberVO vo);
        
        /**
         * parameter로 받은 회원의 정보를 가져오는 메소드
         * @param id 조회할 회원 id
         * @return 해당 회원의 정보
         */
        public MemberVO getDetail(String id);
        
        public List<MemberVO> selectMemList(Map<String, Object> map);
        
        public int totalMemCount(Map<String, Object> map);
        
        public int updatemypage(MemberVO vo);
        
        public List<FreeVO> freeboardlist(String id);
        
        public List<ProdVO> prodboardlist(String id);
        
        public List<MemberVO> getallblacklist();
}
