package Member.Controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Member.Service.IMemberService;
import Member.Service.MemberServiceImpl;
import Member.VO.MemberVO;
import Member.VO.PageMemVO;


@WebServlet("/MemberSearch.do")
public class MemberSearch extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		//요청시 전송데이터 가져오기
		int page = Integer.parseInt(request.getParameter("page")); // 최초 실행시 1
		String stype = request.getParameter("stype"); // 최초 실행 시 없다
		String sword = request.getParameter("sword"); // 최초 실행 시 없다.
		
		//service객체 얻기
		IMemberService service = MemberServiceImpl.getInstance();
		
		//service메소드 호출하기 - 페이지 처리에 필요한 값들을 계산 
		PageMemVO pvo = service.pageMemInfo(page, stype, sword);
		// startPage endPage totalPage
		
		// service메소드 - list를 select 결과값 받기
		Map<String, Object> map = new HashMap<>();
		map.put("start", pvo.getStart());
		map.put("end", pvo.getEnd());
		map.put("stype", stype);
		map.put("sword", sword);
		List<MemberVO> list = service.selectMemList(map);
		
		//결과값을 request에 저장
		request.setAttribute("listvalue", list);
		request.setAttribute("startPage", pvo.getStartPage());
		request.setAttribute("endPage", pvo.getEndPage());
		request.setAttribute("totalPage", pvo.getTotalPage());
		
		//view페이지로 이동
		request.getRequestDispatcher("/memberview/searchlist.jsp").forward(request, response);
	}


}
