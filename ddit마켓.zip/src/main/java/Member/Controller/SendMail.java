package Member.Controller;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SendMail.do")
public class SendMail extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    request.setCharacterEncoding("utf-8");
	    response.setCharacterEncoding("utf-8");
	    
	    String mail = request.getParameter("selectlist");
	    String mailId = request.getParameter("email");
	    String id = request.getParameter("id");
	    
        String to = mailId + mail;
        // 메일 선택란
        Properties properties = System.getProperties();
        Properties props = new Properties();
        String from = "";
        String host = "";
        System.out.println(mailId);
        System.out.println(mail);
        if(mail.equals("@naver.com") || mailId.contains("@naver.com")) {
            from = "@naver.com";
            host = "smtp.naver.com";
            properties.setProperty("mail.smtp.host", host);
            props.put("mail.smtp.host", "smtp.naver.com");
            props.put("mail.smtp.port", "587");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.ssl.trust", "smtp.naver.com");
        } else if(mail.equals("@gmail.com") || mailId.contains("@gmail.com")) {
            from = "@gmail.com";
            host = "smtp.gmail.com";
            props.put("mail.smtp.host", host);
            props.put("mail.smtp.port", "587");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
        } else if(mail.equals("@daum.net") || mailId.contains("@daum.net")) {
            from = "@daum.net";
            host = "smtp.daum.net";
            props.put("mail.smtp.host", host);
            props.put("mail.smtp.port", "465");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.ssl.enable", "true");
        } else {
            throw new IllegalArgumentException("Invalid email domain: " + mail);
        }

        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                if(mail.equals("@naver.com") || mailId.contains("@naver.com")) {
                    return new PasswordAuthentication("", "");
                } else if(mail.equals("@daum.net") || mailId.contains("@daum.net")) {
                    return new PasswordAuthentication("", "");
                } else if(mail.equals("@gmail.com") || mailId.contains("@gmail.com")) {
                    return new PasswordAuthentication("", "");
                } else {
                    return new PasswordAuthentication("", "");
                }
            }
        });

        try {
            
            MimeMultipart multipart = new MimeMultipart();
             
            MimeBodyPart messageBodyPart = new MimeBodyPart();
            String html = "<html><body> "
                    + "<p style=\'font-size: 1.5em; font-weight: bold;\'>"
                    + "다음 버튼을 클릭하여 새 비밀번호를 설정해주세요. <br>"
                    + "<form method='POST' action='http://localhost/MiddleProject/login/updatePass.jsp'>"
                    + "<input type='hidden' name='memid' value='" + id + "'>"
                    + "<button type='submit'>새 비밀번호 설정</button>"
                    + "</form></body></html>";
            messageBodyPart.setContent(html, "text/html; charset=UTF-8");
             
            multipart.addBodyPart(messageBodyPart);
             
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.setRecipient(Message.RecipientType.TO, new InternetAddress(to));
            message.setSubject("새 비밀번호 설정");
            message.setContent(multipart);

            Transport.send(message);
            System.out.println("Message sent successfully....");
            
            request.setAttribute("success", "ok");
        } catch (MessagingException mex) {
            mex.printStackTrace();
            request.setAttribute("success", "no");
        }
        request.getRequestDispatcher("/memberview/sendOk.jsp").forward(request, response);
	    
	}

}
