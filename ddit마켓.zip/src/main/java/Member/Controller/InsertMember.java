package Member.Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Member.Service.IMemberService;
import Member.Service.MemberServiceImpl;
import Member.VO.MemberVO;

@WebServlet("/InsertMember.do")
public class InsertMember extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		String id = request.getParameter("memid");
		String pass = request.getParameter("mempass");
		String name = request.getParameter("memname");
		String nick = request.getParameter("memnick");
		String bir = request.getParameter("membir");
		String code = request.getParameter("memcode");
		String email = request.getParameter("memmail");
		String add = request.getParameter("memadd");
		String addr = request.getParameter("memaddr");
		String tel = request.getParameter("memtel");
		
		MemberVO vo = new MemberVO();
		
		vo.setMem_id(id);
		vo.setMem_password(pass);
		vo.setMem_name(name);
		vo.setMem_nickname(nick);
		vo.setMem_birth(bir + "-" + code);
		vo.setMem_email(email);
		vo.setMem_address(add + " " + addr);
		vo.setMem_tel(tel);
		
		IMemberService service = MemberServiceImpl.getInstance();
		service.insertMember(vo);
		
		request.getRequestDispatcher("/main/main.jsp").forward(request, response);
//		if(result > 0) {
//			response.sendRedirect();
//		}else {
//			
//		}
		
	}

}
