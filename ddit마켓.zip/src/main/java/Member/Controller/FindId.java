package Member.Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Member.Service.IMemberService;
import Member.Service.MemberServiceImpl;
import Member.VO.MemberVO;

@WebServlet("/FindId.do")
public class FindId extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    request.setCharacterEncoding("utf-8");
	    response.setCharacterEncoding("utf-8");
	    
	    MemberVO vo = new MemberVO();
	    
	    String name = request.getParameter("name");
	    String email = request.getParameter("email");
	    
	    vo.setMem_name(name);
	    vo.setMem_email(email);
	    
	    IMemberService service = MemberServiceImpl.getInstance();
	    
	    String id = service.getMember(vo);
	    
	    request.setAttribute("userId", id);
	    request.getRequestDispatcher("/memberview/findIdResult.jsp").forward(request, response);
	    
	}

}
