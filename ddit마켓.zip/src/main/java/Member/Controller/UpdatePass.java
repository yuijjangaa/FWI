package Member.Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Member.Service.IMemberService;
import Member.Service.MemberServiceImpl;
import Member.VO.MemberVO;

@WebServlet("/UpdatePass.do")
public class UpdatePass extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    request.setCharacterEncoding("utf-8");
	    response.setCharacterEncoding("utf-8");
	    
	    String id = request.getParameter("memid");
	    String pass = request.getParameter("pass");
	    
	    MemberVO vo = new MemberVO();
	    vo.setMem_id(id);
	    vo.setMem_password(pass);
	    
	    IMemberService service = MemberServiceImpl.getInstance();
	    
	    int cnt = service.updatePass(vo);
	    
	    request.setAttribute("result", cnt);
	    request.getRequestDispatcher("/memberview/result.jsp").forward(request, response);
	}

}
