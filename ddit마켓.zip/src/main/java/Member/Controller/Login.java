package Member.Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Member.Service.IMemberService;
import Member.Service.MemberServiceImpl;
import Member.VO.MemberVO;
import alarm.Service.AlarmServiceImpl;
import alarm.Service.IAlarmService;
import alarm.VO.AlarmVO;
import chat.Service.ChatServiceImpl;
import chat.Service.IChatService;
import chat.VO.ChatVO;

@WebServlet("/Login.do")
public class Login extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");

        response.setContentType("text/html; charset=utf-8");

        String id = request.getParameter("id");
        String pass = request.getParameter("pass");

        IMemberService service = MemberServiceImpl.getInstance();
        
        MemberVO vo = service.getMemberId(id);
        
        HttpSession session = request.getSession();

        // 관리자 여부
        if ("admin".equals(id) && "admin1234".equals(pass)) {
            session.setAttribute("userId", id);
            session.setAttribute("password", pass);
            session.setAttribute("ok", "ok");
            response.sendRedirect(request.getContextPath() + "/main/main.jsp");

            // 회원 로그인
        } else if (vo != null && pass.equals(vo.getMem_password())) {
            session.setAttribute("userId", id);
            session.setAttribute("password", pass);
            session.setAttribute("ok", "no");
            response.sendRedirect(request.getContextPath() + "/main/main.jsp");

        } else {
            request.setAttribute("message", "아이디 또는 비밀번호가 일치하지 않습니다.");
            request.getRequestDispatcher("/login/Login.jsp").forward(request, response);
        }
    }
}

