package Member.Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import Member.Service.IMemberService;
import Member.Service.MemberServiceImpl;


@WebServlet("/IDCheck.do")
public class IDCheck extends HttpServlet { 
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		String id = request.getParameter("id");
		IMemberService service = MemberServiceImpl.getInstance();
		int cnt = service.checkID(id);
		
		String pop = "";
		if(cnt > 0) {
			pop = "이미 존재하는 아이디입니다.";
		} else {
			pop = "사용가능한 아이디입니다.";
		}
		
		Gson gson = new Gson();
		String res = gson.toJson(pop);
		response.getWriter().write(res);
		response.flushBuffer();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
