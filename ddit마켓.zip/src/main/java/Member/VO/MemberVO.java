package Member.VO;

public class MemberVO {
    
    private String mem_id;
    private String mem_password;
    private String mem_name;
    private String mem_nickname;
    private String mem_birth;
    private String mem_email;
    private String mem_address;
    private String mem_tel;
    
    private int mem_report;
    private int mem_blacklist;
    
    public String getMem_id() {
        return mem_id;
    }
    public void setMem_id(String mem_id) {
        this.mem_id = mem_id;
    }
    public String getMem_password() {
        return mem_password;
    }
    public void setMem_password(String mem_password) {
        this.mem_password = mem_password;
    }
    public String getMem_name() {
        return mem_name;
    }
    public void setMem_name(String mem_name) {
        this.mem_name = mem_name;
    }
    public String getMem_nickname() {
        return mem_nickname;
    }
    public void setMem_nickname(String mem_nickname) {
        this.mem_nickname = mem_nickname;
    }
    public String getMem_birth() {
        return mem_birth;
    }
    public void setMem_birth(String mem_birth) {
        this.mem_birth = mem_birth;
    }
    public String getMem_email() {
        return mem_email;
    }
    public void setMem_email(String mem_email) {
        this.mem_email = mem_email;
    }
    public String getMem_address() {
        return mem_address;
    }
    public void setMem_address(String mem_address) {
        this.mem_address = mem_address;
    }
    public String getMem_tel() {
        return mem_tel;
    }
    public void setMem_tel(String mem_tel) {
        this.mem_tel = mem_tel;
    }
    public int getMem_blacklist() {
        return mem_blacklist;
    }
    public void setMem_blacklist(int mem_blacklist) {
        this.mem_blacklist = mem_blacklist;
    }
	public int getMem_report() {
		return mem_report;
	}
	public void setMem_report(int mem_report) {
		this.mem_report = mem_report;
	}
    

}
