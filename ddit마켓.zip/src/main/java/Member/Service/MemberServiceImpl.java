package Member.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Anno.VO.PageVO;
import Free.VO.FreeVO;
import Member.Dao.IMemberDao;
import Member.Dao.MemberDaoImpl;
import Member.VO.MemberVO;
import Member.VO.PageMemVO;
import prodboard.VO.ProdVO;

public class MemberServiceImpl implements IMemberService {
    private static MemberServiceImpl service;
    private static IMemberDao dao;
    
    private MemberServiceImpl() {
        dao = MemberDaoImpl.getInstance();
    }
    
    public static MemberServiceImpl getInstance() {
        if(service == null) service = new MemberServiceImpl();
        return service;
    }
    
    @Override
    public MemberVO getMemberId(String id) {
        return dao.getMemberId(id);
    }

    @Override
    public String getMember(MemberVO vo) {
        return dao.getMember(vo);
    }

    @Override
    public int updatePass(MemberVO vo) {
        return dao.updatePass(vo);
    }
    
    @Override
    public List<MemberVO> getAllMember() {
        return dao.getAllMember();
    }


    @Override
    public int insertMember(MemberVO MemberVO) {
        return dao.insertMember(MemberVO);
    }

    @Override
    public int checkID(String id) {
        return dao.checkID(id);
    }

    @Override
    public int updateMember(MemberVO vo) {
        return dao.updateMember(vo);
    }
    
    @Override
    public MemberVO getDetail(String id) {
    	return dao.getDetail(id);
    }

	@Override
	public List<MemberVO> selectMemList(Map<String, Object> map) {
		return dao.selectMemList(map);
	}
	@Override
	public int totalMemCount(Map<String, Object> map) {
		return dao.totalMemCount(map);
	}
	@Override
	public PageMemVO pageMemInfo(int page, String stype, String sword) {
		//전체글 갯수 구하기
				Map<String, Object> map = new HashMap<>();
				
				map.put("sword", sword);
				map.put("stype", stype);
				
				int count = this.totalMemCount(map);
				
				//전체페이지수 구하기
				int totalPage = (int)Math.ceil((double)count / PageMemVO.getPerList());
				
				//start, end 구하기
				int start = (page-1) * PageMemVO.getPerList() + 1;
				int end = start + PageMemVO.getPerList() - 1;
				
				if(end > count) end = count;
				
				//시작페이지 끝페이지
				int perPage = PageMemVO.getPerPage();
				int startPage = ((page-1) / perPage * perPage) + 1;
				
				int endPage = startPage + perPage - 1;
				if(endPage > totalPage) endPage = totalPage;
				
				PageMemVO vo = new PageMemVO();
				vo.setStart(start);
				vo.setEnd(end);
				
				vo.setStartPage(startPage);
				vo.setEndPage(endPage);
				vo.setTotalPage(totalPage);
				
				return vo;
	}

	@Override
	public int updatemypage(MemberVO vo) {
		return dao.updatemypage(vo);
	}

	@Override
	   public List<FreeVO> freeboardlist(String id) {
	      return dao.freeboardlist(id);
	}
	
	@Override
	   public List<ProdVO> prodboardlist(String id) {
	      return dao.prodboardlist(id);
	}
	
	@Override
    public List<MemberVO> getallblacklist() {
        // TODO Auto-generated method stub
        return dao.getallblacklist();
    }
	
}
