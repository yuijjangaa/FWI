package inquiries.VO;

public class InquiriesVO {
    private int inquiry_id;
    private String user_id;
    private String inquiry_title;
    private String inquiry_content;
    private String created_at;
    private int hit;
    public int getInquiry_id() {
        return inquiry_id;
    }
    public void setInquiry_id(int inquiry_id) {
        this.inquiry_id = inquiry_id;
    }
    public String getUser_id() {
        return user_id;
    }
    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }
    public String getInquiry_title() {
        return inquiry_title;
    }
    public void setInquiry_title(String inquiry_title) {
        this.inquiry_title = inquiry_title;
    }
    public String getInquiry_content() {
        return inquiry_content;
    }
    public void setInquiry_content(String inquiry_content) {
        this.inquiry_content = inquiry_content;
    }
    public String getCreated_at() {
        return created_at;
    }
    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }
    public int getHit() {
        return hit;
    }
    public void setHit(int hit) {
        this.hit = hit;
    }
}
