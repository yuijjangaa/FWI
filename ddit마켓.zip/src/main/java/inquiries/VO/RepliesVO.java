package inquiries.VO;

public class RepliesVO {
    private int inqui_reply_id;
    private String admin_id;
    private String inquiry_id;
    private String inqui_reply_content;
    private String created_at;
    
    public int getInqui_reply_id() {
        return inqui_reply_id;
    }
    public void setInqui_reply_id(int inqui_reply_id) {
        this.inqui_reply_id = inqui_reply_id;
    }
    public String getAdmin_id() {
        return admin_id;
    }
    public void setAdmin_id(String admin_id) {
        this.admin_id = admin_id;
    }
    public String getInquiry_id() {
        return inquiry_id;
    }
    public void setInquiry_id(String inquiry_id) {
        this.inquiry_id = inquiry_id;
    }
    public String getInqui_reply_content() {
        return inqui_reply_content;
    }
    public void setInqui_reply_content(String inqui_reply_content) {
        this.inqui_reply_content = inqui_reply_content;
    }
    public String getCreated_at() {
        return created_at;
    }
    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }
    
    
}
