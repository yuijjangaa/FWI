package inquiries.Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import inquiries.Service.BoardServiceImpl;
import inquiries.Service.IBoardService;
import inquiries.VO.RepliesVO;


@WebServlet("/replyWrite.do")
public class ReplyWrite extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		// 요청 시 전송데이터 받기 - name, bonum, cont
		String repName = request.getParameter("name");
		int repBonum = Integer.parseInt(request.getParameter("bonum"));
		String repCont = request.getParameter("cont");
		
		RepliesVO vo = new RepliesVO();
		
		// service객체 얻기
		IBoardService service = BoardServiceImpl.getInstance();
		
		// service메소드 호출 - 결과값을 받기
		int cnt = service.insertReply(vo);
		
		// 결과값을 request에 저장
		request.setAttribute("result", cnt);
		
		// view페이지로 이동
		request.getRequestDispatcher("qnaBoardview/result.jsp").forward(request, response);
	}

}
