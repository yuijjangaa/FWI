package inquiries.Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import inquiries.Service.BoardServiceImpl;
import inquiries.Service.IBoardService;
import inquiries.VO.InquiriesVO;

@WebServlet("/boardWrite.do")
public class InquiryBoardWrite extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		InquiriesVO vo = new InquiriesVO();
		vo.setInquiry_content(request.getParameter("content"));
		vo.setUser_id(request.getParameter("memId"));
		vo.setInquiry_title(request.getParameter("title"));
		
		IBoardService service = BoardServiceImpl.getInstance();
		
		int cnt = service.insertBoard(vo);
		
		if(cnt>0) {
		    request.getRequestDispatcher("/qnaBoard/qnalist.jsp").forward(request, response);
		} 
		
	}

}
