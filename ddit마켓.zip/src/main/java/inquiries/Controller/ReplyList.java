package inquiries.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import inquiries.Service.BoardServiceImpl;
import inquiries.Service.IBoardService;
import inquiries.VO.RepliesVO;


@WebServlet("/replyList.do")
public class ReplyList extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		String bonum = request.getParameter("bonum");
		
		IBoardService service = BoardServiceImpl.getInstance();
		
		List<RepliesVO> list = service.selectReply(bonum);
		
		request.setAttribute("replyList", list);
		
		request.getRequestDispatcher("/qnaBoard/replyList.jsp").forward(request, response);
	}

}
