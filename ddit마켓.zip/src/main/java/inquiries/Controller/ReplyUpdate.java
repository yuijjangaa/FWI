package inquiries.Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import inquiries.Service.BoardServiceImpl;
import inquiries.Service.IBoardService;
import inquiries.VO.RepliesVO;


@WebServlet("/qnaReplyUpdate.do")
public class ReplyUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ReplyUpdate() {
        super();
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		//요청시 전송데이터 받기 - cont, renum - vo에 저장
		RepliesVO vo = new RepliesVO();
		vo.setInqui_reply_content(request.getParameter("cont"));
		vo.setInqui_reply_id(Integer.parseInt(request.getParameter("renum")));
		
		//service객체 얻기
		IBoardService service = BoardServiceImpl.getInstance();
		
		//service메소드 호출 - 결과값 받기
		int res = service.updateReply(vo);
		
		//request에  결과값 저장
		request.setAttribute("result", res);
		
		//view페이지로 이동 - result.jsp
		request.getRequestDispatcher("/qnaBoardview/result.jsp").forward(request, response);
		
	}

}
