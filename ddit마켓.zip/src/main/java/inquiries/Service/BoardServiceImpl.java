package inquiries.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import inquiries.Dao.BoardDaoImpl;
import inquiries.Dao.IBoardDao;
import inquiries.VO.InquiriesVO;
import inquiries.VO.PageVO;
import inquiries.VO.RepliesVO;

public class BoardServiceImpl implements IBoardService {
	private static IBoardDao dao;
	private static BoardServiceImpl service;
	
	private BoardServiceImpl() {
		dao = BoardDaoImpl.getInstance();
	}
	
	public static BoardServiceImpl getInstance() {
		if(service == null) service = new BoardServiceImpl();
		return service;
	}

	@Override
	public PageVO pageInfo(int page, String stype, String sword) {
		
		// 전체글 갯수 구하기
		Map<String, Object> map = new HashMap<>();
		map.put("sword", sword);
		map.put("stype", stype);
		
		int cnt = this.totalCount(map);
		
		// 전체페이지수 구하기
		int totalPage = (int) Math.ceil((double) cnt / PageVO.getPerList());
		
		//start, end 구하기
		int start = (page-1) * PageVO.getPerList() + 1;
		int end = start + PageVO.getPerList() - 1;
		
		if(end > cnt) end = cnt;
		
		// 시작페이지 끝페이지
		int perPage = PageVO.getPerPage();
		int startPage = ((page-1) / perPage * perPage) + 1;
		int endPage = startPage + perPage - 1;
		if(endPage > totalPage) endPage = totalPage;
		PageVO vo = new PageVO();
		vo.setStartPage(startPage);
		vo.setEndPage(endPage);
		vo.setStart(start);
		vo.setEnd(end);
		vo.setTotalpage(totalPage);
		return vo;
	}

    @Override
    public int insertBoard(InquiriesVO vo) {
        return dao.insertBoard(vo);
    }

    @Override
    public int deleteBoard(int id) {
        return dao.deleteBoard(id);
    }

    @Override
    public int updateHit(int num) {
        return dao.updateHit(num);
    }

    @Override
    public List<InquiriesVO> selectByPage(Map<String, Object> map) {
        return dao.selectByPage(map);
    }

    @Override
    public List<RepliesVO> selectReply(String id) {
        return dao.selectReply(id);
    }

    @Override
    public int insertReply(RepliesVO vo) {
        return dao.insertReply(vo);
    }

    @Override
    public int deleteReply(String id) {
        return dao.deleteReply(id);
    }
    
    @Override
	public int updateReply(RepliesVO vo) {
		return dao.updateReply(vo);
	}

    @Override
    public int totalCount(Map<String, Object> map) {
        return dao.totalCount(map);
    }
    

}
