package inquiries.Dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import Util.mybatisSqlSessionFactory;
import inquiries.VO.InquiriesVO;
import inquiries.VO.RepliesVO;

public class BoardDaoImpl implements IBoardDao {
	private static BoardDaoImpl dao;
	
	private BoardDaoImpl() {
	}
	
	
	public static BoardDaoImpl getInstance() {
		if(dao == null) dao = new BoardDaoImpl();
		return dao;
	}

	@Override
	public int insertBoard(InquiriesVO vo) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = Util.mybatisSqlSessionFactory.getSqlSession();
			cnt = session.insert("inquiries.insertBoard", vo);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		}
		return cnt;
	}

	@Override
	public int deleteBoard(int id) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.delete("inquiries.deleteBoard", id);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		}
		return cnt;
	}

	@Override
	public int updateHit(int num) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = Util.mybatisSqlSessionFactory.getSqlSession();
			cnt = session.update("inquiries.updateHit", num);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		}
		return cnt;
	}

	@Override
	public List<InquiriesVO> selectByPage(Map<String,Object> map) {
		SqlSession session = null;
		List<InquiriesVO> list = null;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			list = session.selectList("inquiries.selectByPage", map);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		}
		return list;
	}

	@Override
	public int insertReply(RepliesVO vo) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.insert("inquiries.insertReplies", vo);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		}
		return cnt;
	}

	@Override
	public int deleteReply(String id) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.delete("inquiries.deleteReply", id);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		}
		return cnt;
	}

	@Override
	public int totalCount(Map<String, Object> map) {
		SqlSession session = null;
		int cnt = 0;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			cnt = session.selectOne("inquiries.totalCount", map);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		}
		return cnt;
	}


	@Override
	public List<RepliesVO> selectReply(String id) {
		SqlSession session = null;
		List<RepliesVO> list = null;
		try {
			session = mybatisSqlSessionFactory.getSqlSession();
			list = session.selectList("inquiries.selectReplies", id);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return list;
	}


	@Override
	public int updateReply(RepliesVO vo) {
		int res = 0;
		SqlSession session = mybatisSqlSessionFactory.getSqlSession();
		
		try {
			res = session.update("board.updateReply", vo);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.commit();
			session.close();
		}
		return res;
	}




}
