package inquiries.Dao;

import java.util.List;
import java.util.Map;

import inquiries.VO.InquiriesVO;
import inquiries.VO.RepliesVO;

public interface IBoardDao {
	
 // 글 쓰기 - 실행된 행의 갯수를 리턴 - 시퀀스값을 리턴
    public int insertBoard(InquiriesVO vo);
    
    // 글 삭제
    public int deleteBoard(int id);
    
    // 조회수 증가
    public int updateHit(int num);
    
    // 리스트 - 검색 포함
    public List<InquiriesVO> selectByPage(Map<String,Object> map);
    
    // 댓글 리스트
    public List<RepliesVO> selectReply(String id);
    
    // 댓글 쓰기
    public int insertReply(RepliesVO vo);
    
    // 댓글 삭제
    public int deleteReply(String id);
    
    //댓글 수정
    public int updateReply(RepliesVO vo);
    
    // 전체글 갯수 구하기
    public int totalCount(Map<String,Object> map);
    
}
