/**
 * 
 */
$.hitUpdateServer = function(target) {
	
	$.ajax({
		url : `${mypath}/HitUpdate.do`,
		data : {"id" : vidx},
		type : 'get',
		success : function(res){
			if(res.flag == "ok"){ 
				//화면수정
						
			vhit = $(target).parents('.card').find('#hit');				
				
			hitp =	parseInt($(vhit).text()) + 1;
			
			$(vhit).text(hitp)
			}
		},
		error : function(xhr){
			alert("상태 : " + xhr.status)
		},
		dataType : 'json'
		
	})
}

$.boardUpdate = function() {
	
	$.ajax({
		url : `${mypath}/BoardUpdate.do`,
		type : 'post',
		data : fdata,
		success : function(res){
		vparents = $(vmodify).parents('.card');
        $(vparents).find('a').text(vms);
        $(vparents).find('.wp3').html(vmc);
		},
		error : function(xhr){
			alert("상태 : " + xhr.status)
		},
		dataType : 'json'
		
	})
}
$.boardDeleteServer = function(){
		$.ajax({
		url :  `${mypath}/BoardDelete.do`,
		type : 'get',
		data : {"id" : vidx},
		success : function(res) {
			currentPage = 1;
			$.listPageServer(currentPage);
		},
		error : function(xhr) {
			alert("상태 : " + xhr.status)
		},
		dataType : 'json'
		})
}


$.boardWriteServer = function(){
	$.ajax({
		url : `${mypath}/BoardWrite.do`,
		type : 'post',
		data : fdata,
		success : function(res){
			if(res.flag == "ok"){
				currentPage = 1;
				$.listPageServer(currentPage);
			}
		},
		erroer : function(xhr){
			alert("상태 : " + xhr.status);
		},
		dataType : 'json'
	})
}


$.listPageServer = function(cpage) {
	
	vtype = $('#stype option:selected').val().trim();
	 vword = $('#sword').val().trim();
	 
	$.ajax({
		url  : `${mypath}/BoardList.do`,
		type : 'post',
		data : {
			"page" : cpage,
			"stype" : vtype,
			"sword" : vword
		},
		success : function (res) {
			
			code = `<div class="container mt-3">
					<div id="accordion">`;
			$.each(res.datas, function(i, v) {
				
				detail = v.anno_detail;
				
				//detail = detail.replaceAll(/\n/g, "<br>");
				
				code += `<div class="card">
			      <div class="card-header">
			        <a class="btn action" idx="${v.anno_id}" name="list" data-bs-toggle="collapse" href="#collapse${v.anno_id}">
			         <span id="title">${v.anno_title}<span>
			        </a>
			      </div>
			      <div id="collapse${v.anno_id}" class="collapse" data-bs-parent="#accordion">
			        <div class="card-body">
			         	<p class="p1">
			         		날짜 <span id="da">${v.anno_createdate}</span>&nbsp;&nbsp;&nbsp;
			         		조회수 <span id="hit">${v.anno_views}</span>&nbsp;&nbsp;&nbsp;
			         		</p>
			         	<p class="p3 wp3">
			         		${detail} 
			         	</p>
			         	<p class="p2">
			         		<input type="button" idx="${v.anno_id}"  name="delete" class="action" value="삭제">
			         		<input type="button" idx="${v.anno_id}"  name="modify" class="action" value="수정">
			         	</p>
			         	
			        </div>
			      </div>
			    </div>`
			
			})//$.each
			code += `</div>
					</div>`
			// 리스트 출력
			$('#result').html(code);
					
			// 페이지 처리
			
			// 이전
			pager = "";
			pager += `<ul class="pagination">`;
			if(res.sp > 1){
				pager += `<li class="page-item"><a id="prev" class="page-link" href="#anno">이전 페이지</a></li>`
				
			}
			
			// 페이지 번호
			for(i=res.sp; i<= res.ep; i++){
				if(i == currentPage){
					pager += `<li class="page-item active"><a class="page-link pageno" href="#anno">${i}</a></li>`
				}else{
					pager += `<li class="page-item"><a class="page-link pageno" href="#anno">${i}</a></li>`
				}
			}
			// 다음
			if(res.ep < res.tp){
				pager += `<li class="page-item"><a id="next" class="page-link" href="#anno">다음 페이지</a></li>`
			}
			pager += `</ul>`;
			
			$('#pagelist').html(pager);
			buttonShow();
			
		},//success
		error : function (xhr) {
			alert("상태 : " + xhr.status)
		},
		dataType : 'json'
	})	
}



$.hitUpdate = function(target) {
	
	$.ajax({
		url : `${mypath}/hitUpdate.do`,
		data : {"id" : vid},
		type : 'get',
		success : function(res){
			if(res.flag == "ok"){ 
				//화면수정
						
			vhit = $(target).parents('.card').find('#hit');				
				
			hitp =	parseInt($(vhit).text()) + 1;
			
			$(vhit).text(hitp)
			}
		},
		error : function(xhr){
			alert("상태 : " + xhr.status)
		},
		dataType : 'json'
		
	})
}

$.boardDelete = function(){
		$.ajax({
		url :  `${mypath}/boardDelete.do`,
		type : 'get',
		data : {"id" : vid},
		success : function(res) {
			currentPage = 1;
			$.listPage(currentPage);
		},
		error : function(xhr) {
			alert("상태 : " + xhr.status)
		},
		dataType : 'json'
		})
}


$.boardWrite = function(){
	$.ajax({
		url : `${mypath}/boardWrite.do`,
		type : 'post',
		data : fdata,
		success : function(res){
			if(res.flag == "ok"){
				currentPage = 1;
				$.listPageServer(currentPage);
			}
		},
		erroer : function(xhr){
			alert("상태 : " + xhr.status);
		},
		dataType : 'json'
	})
}

$.replyListServer = function(target){ //target : 클릭한 등록버튼, 클릭한 제목
	$.ajax({
		url : `${mypath}/replyList.do`,
		type : 'get',
		data: { "bonum": vidx }, //{" bonum " : reply.bonum },
		success : function(res){
			//target : 클릭한 등록버튼을 기준으로 출력
			rcode = "";
			$.each(res,function(i,v){
					content = v.cont;
					
					content = content.replaceAll(/\n/g, "<br>");
					
				  rcode += `<div class="reply-body">
                       <p class="p1">
                          작성자 : <span id="rwr">${v.name}</span>&nbsp;&nbsp;&nbsp; 
                          날짜 : <span id="rda">${v.redate}</span>&nbsp;&nbsp;&nbsp; 
                       </p>
                       <p class="p2">
                          <input type="button" idx="${v.renum}" name="r_delete" class="action" value=" 댓글 삭제 ">
                          <input type="button" idx="${v.renum}" name="r_modify" class="action" value=" 댓글 수정 ">
                       </p>
                       <p class="p3">
                          ${content}
                       </p>
                	</div>`
				
			})//$.each
			//출력
			$(target).parents('.card').find('.reply-body').remove();
			$(target).parents('.card').find('.card-body').append(rcode); 
			
		},  //success
		error : function(xhr){
			alert("상태 : " + xhr.status);
		}, 
		dataType : 'json'

	})

}

$.deleteReplyServer = function(target){ //target : 클릭한 댓글삭제버튼
	$.ajax({
		url : `${mypath}/replyDelete.do`,
		type: `get`,
		data : {"renum" : vidx},
		success : function(res){
			//alert(res.flag);
			if(res.flag == "ok"){
				$(target).parents('.reply-body').remove();
			}
		}, 
		error : function(xhr){
			alert(xhr.status);
		},
		dataType : 'json'
	})
}

$.replyUpdateServer = function(){
		$.ajax({
			url : `${mypath}/qnaReplyUpdate.do`,
			type : 'post',
			data : reply,
			success : function(res){
				alert(res.flag);
			},
			error : function(xhr){
				alert("상태 : " + xhr.status);
			},
			dataType : 'json'
		})
}







