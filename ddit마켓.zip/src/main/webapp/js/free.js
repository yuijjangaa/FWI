/**
 * 
 */

$.replyUpdateServer = function () {
   
   $.ajax({
      url :  `${mypath}/ReplyUpdate.do`,
      type : 'post',
      data : reply,
      success : function(res) {
         if(res.flag == "ok") {
            $(vp3).html(modiout);
         } else {
            alert("권한이 없습니다.")
         }
      },
      error : function(xhr){
         alert("상태 : " + xhr.status)
      },
      dataType : 'json'
   })
}
$.deleteReplyServer = function (target) { //target : 클릭한 댓글 삭제 버튼
   $.ajax({
      url :  `${mypath}/ReplyDelete.do`,
      type : 'get',
      data : {"reply_id" : vidx},
      success : function(res){
         if(res.flag == "ok"){
            $(target).parents('.reply-body').remove();
         } else{
            alert("권한이 없습니다.")   
         
         }
      },
      error : function(xhr){
         alert(xhr.status);
      },
      dataType : 'json'
   })
}
$.replyWriteServer = function(re){
   $.ajax({
      url : `${mypath}/ReplyWrite.do`,
      type : 'post',
      data : reply, 
      success : function(res){
         //저장성공
         if(res.flag == "ok"){            
         //댓글내용 출력 - 등록버튼(re)을 기준으로 출력
         //$(re)
         $.replyListServer(re);
         
         }
      },
      error : function(xhr){
         alert("상태 : " + xhr.status);
      },
      dataType : 'json'
   })
}
$.replyListServer = function(target){   //target : 클릭한 등록버튼, 클릭한 제목
   $.ajax({
      url : `${mypath}/ReplyList.do`,
      type : 'get',
      data : { "freeid": vidx },   //{ 
      success : function(res){
         //target : 클릭한 등록버튼을 기준으로 출력
         rcode = ""
         $.each(res, function(i,v){
            content = v.reply_content;
            
            content = content.replaceAll(/\r/g, "").replaceAll(/\n/g, "<br>");
            
         rcode += `<div class="reply-body">
                     <p class="p1">
                        작성자 <span id="wr">${v.mem_id}</span>&nbsp;&nbsp;&nbsp;
                        날짜 <span id="da">${v.reply_regdate}</span>&nbsp;&nbsp;&nbsp;
                        </p>
                     <p class="p3">
                        ${content}
                     </p>
                     <p class="p2">
                        <input type="button" id="delete" idx="${v.reply_id}" name="r_delete" class="action" value="댓글삭제">
                        <input type="button" idx="${v.reply_id}" name="r_modify" class="action" value="댓글수정">
                     </p>
                 </div>`
         }) //$.each
         //출력
         
         $('#result').html(rcode);
         
      },//succ
      error : function(xhr){
         alert("상태 : " + xhr.status);
      },
      dataType : 'json'
   }) //%ajax
} //
$.boardUpdate = function() {
   
   $.ajax({
      url : `${mypath}/FreeUpdate.do`,
      type : 'post',
      data : fdata,
      success : function(res){if(res.flag == "ok"){
            vparents = $(vmodify).parents('.board_view');
              $(vparents).find('input').text(vms);
              $(vparents).find('.cont').html(vmc);
         currentPage = 1;
         $.listPageServer(currentPage);
         } else {
            alert("수정권한이 없습니다.")
         }
      },
      error : function(xhr){
         alert("상태 : " + xhr.status)
      },
      dataType : 'json'
      
   })
}
$.boardDeleteServer = function(){
      $.ajax({
      url :  `${mypath}/FreeDelete.do`,
      type : 'get',
      data : {"id" : vidx},
      success : function(res) {
         if(res.flag == "ok"){
         currentPage = 1;
         $.listPageServer(currentPage);
         } else {
            alert("삭제권한이 없습니다.")
         }
      },
      error : function(xhr) {
         alert("상태 : " + xhr.status)
      },
      dataType : 'json'
      })
}
$.boardWriteServer = function(){
   $.ajax({
      url : `${mypath}/FreeWrite.do`,
      type : 'post',
      data : fdata,
      success : function(res){
         if(res.flag == "ok"){
            currentPage = 1;
            $.listPageServer(currentPage);
         }
      },
      erroer : function(xhr){
         alert("상태 : " + xhr.status);
      },
      dataType : 'json'
   })
}
$.listPageServer = function(cpage) {
   
   vtype = $('#stype option:selected').val();
    vword = $('#sword').val();
    
   $.ajax({
      url  : `${mypath}/FreeList.do`,
      type : 'post',
      data : {
         "page" : cpage,
         "stype" : vtype,
         "sword" : vword
      },
      success : function (res) {
         
         code = `<div class="board_list_wrap">
                 <table class="board_list">
                 <tr class="top">
                    <td class="num">&nbsp;&nbsp;글번호</td>
                    <td class="title">제목</td>
                    <td class="writer">작성자</td>
                    <td class="date">작성일</td>
                    <td class="count">조회</td>
                </tr>`;
         $.each(res.datas, function(i, v) {
            
            //detail = detail.replaceAll(/\n/g, "<br>");
            
            code += `<tr>
                          <td class="btn action" idx="${v.freeboard_id} name="list" href="#collapse${v.freeboard_id}">${v.freeboard_id}</td>
                          <td class="title"><a href="${mypath}/FreeInfo.do?freeid=${v.freeboard_id}">${v.fb_title}</a></td>
                          <td class="writer">${v.mem_id}</td>
                          <td class="da">${v.fb_createdate}</td>
                          <td class="hit">${v.fb_views
                          }</td>
                      </tr>` 
                 
         })//$.each
         code += `</table>
               </div>`
         // 리스트 출력
         $('#result').html(code);
               
         // 페이지 처리
         
         // 이전
         pager = "";
         pager += `<ul class="pagination">`;
         if(res.sp > 1){
            pager += `<li class="page-item"><a id="prev" class="page-link" href="#">이전 페이지</a></li>`
            
         }
         
         // 페이지 번호
         for(i=res.sp; i<= res.ep; i++){
            if(i == currentPage){
               pager += `<li class="page-item active"><a class="page-link pageno" href="#">${i}</a></li>`
            }else{
               pager += `<li class="page-item"><a class="page-link pageno" href="#">${i}</a></li>`
            }
         }
         // 다음
         if(res.ep < res.tp){
            pager += `<li class="page-item"><a id="next" class="page-link" href="#">다음 페이지</a></li>`
         }
         pager += `</ul>`;
         
         $('#pagelist').html(pager);
         
      },//success
      error : function (xhr) {
         alert("상태 : " + xhr.status)
      },
      dataType : 'json'
      
   })
}
