/**
 * 
 */
$.memlist = function(cpage) {
	
	vtype = $('#stype option:selected').val().trim();
	 vword = $('#sword').val().trim();
	 
	$.ajax({
		url  : `${mypath}/MemberSearch.do`,
		type : 'post',
		data : {
			"page" : cpage,
			"stype" : vtype,
			"sword" : vword
		},
		success : function (res) {
			
			code = `<table border="1" class="table table-striped">
						<tr>
							<th>ID</th>
							<th>이름</th>
							<th>닉네임</th>
							<th>전화번호</th>
							<th>이메일</th>
							<th>주소</th>
						</tr>`
			$.each(res.datas, function(i, v) {
				
				
				
				code +=
					`<tr>
					<td>${v.mem_id}</td>
					<td>${v.mem_name}</td>
					<td>${v.mem_nickname}</td>
					<td>${v.mem_tel}</td>
					<td>${v.mem_email}</td>
					<td>${v.mem_address}</td>
					</tr>`
			
			})//$.each
			code += `</div>
					</table>`
					
			// 리스트 출력
			$('#memResult').html(code);
					
			// 페이지 처리
			
			// 이전
			pager = "";
			pager += `<ul class="pagination">`;
			if(res.sp > 1){
				pager += `<li class="page-item"><a id="prev" class="page-link" href="#anno">이전 페이지</a></li>`
				
			}
			
			// 페이지 번호
			for(i=res.sp; i<= res.ep; i++){
				if(i == currentPage){
					pager += `<li class="page-item active"><a class="page-link pageno" href="#anno">${i}</a></li>`
				}else{
					pager += `<li class="page-item"><a class="page-link pageno" href="#anno">${i}</a></li>`
				}
			}
			// 다음
			if(res.ep < res.tp){
				pager += `<li class="page-item"><a id="next" class="page-link" href="#anno">다음 페이지</a></li>`
			}
			pager += `</ul>`;
			
			$('#memPagelist').html(pager);
			
		},//success
		error : function (xhr) {
			alert("상태 : " + xhr.status)
		},
		dataType : 'json'
	})	
}